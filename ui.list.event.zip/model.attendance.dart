import 'util.firebase.dart';
import 'model.date.dart';
import 'model.feedback.dart';
import 'dart:async';

class ParticipationPresenter {
  static void setEventAttendeeFeedback(String eventID, String userID, String name, List<Response> responses, void feedbackSubmitted()) {
    List<dynamic> responseMap = <dynamic>[];
    responses.forEach((Response r) {
      responseMap.add(r.responseMap);
    });
    FirebaseMethods.setFeedbackAnswers(
        eventID,
        userID,
        {
          'Feedback': responseMap,
          'UserID': userID,
          'FeedbackKey': eventID,
          'Name': name,
          'Time': DateTime.now().toString(),
        },
        feedbackSubmitted);
  }

  static void setEventQuestion(String eventID, String userID, String name, String question, void questionSubmitted()) {
    FirebaseMethods.setEventQuestion(
      eventID,
      {
        'Name': name,
        'UserID': userID,
        'Photo': "",
        "Question": question,
        "QuestionKey": eventID,
        "Time": DateTime.now().toString(),
      },
      questionSubmitted,
    );
  }
}

class Question {
  String name;
  String question;
  String userID;
  String key;
  int votes = 0;

  Question.retrieveQuestion(this.key, Map data) {
    name = data['Name'];
    userID = data['UserID'];
    question = data['Question'] != null ? data['Question'] : "";
  }
}

class AttendancePresenter {
  static void getCalendar(String userID, void calendarRetrieved(Map data)) {
    FirebaseMethods.getCalendarByUserID(userID, (Map data) {
      calendarRetrieved(data);
    });
  }

  static void getAttendance(String eventID, void attendanceRetrieved(Map data)) {
    FirebaseMethods.getAttendeesByEventID(eventID, (Map data) {
      attendanceRetrieved(data);
    });
  }

  static void getQuestions(String eid, void done(Map data), void returnSS(StreamSubscription s)) {
//    FirebaseMethods.getEventQuestionsByEventID(eid, done);
    FirebaseMethods.getEventQuestionsByEventIDRefresh(eid, done).then(returnSS);
  }

  static void setAttendance(bool checkedIn, String eventID, String userKey, void attendanceSet(Map data)) {
    FirebaseMethods.setAttendanceByAttendee(eventID, userKey, {'Status': checkedIn, 'Time': DateTime.now().toString()}, attendanceSet);
  }

  static void getNotifications(String userID, void onData(Map data), void returnSS(StreamSubscription s)) {
    FirebaseMethods.getAllNotificationsByUserID(userID, onData).then(returnSS);
  }

  static void setVote(String eventID, String questionID, String userID, void done()) {
    FirebaseMethods.setQuestionVoteByUserID(eventID, questionID, userID, done);
  }

//  static void setVote(String eventID, String questionID, String userID, void done(Map data)) {
//    FirebaseMethods.setQuestionVoteByUserID(eventID, questionID, userID, done);
//  }

  static void setAttendanceCancel(String eventID, String reason, String userKey, void attendanceCancelled(Map data)) {
    FirebaseMethods.setAttendanceByAttendee(eventID, userKey, {'Reason': reason}, attendanceCancelled);
  }

  static void setFeedback(String eventID, String userKey, void attendanceSet(Map data)) {
    FirebaseMethods.setAttendanceFeedbackSent(eventID, userKey, attendanceSet);
  }
}

class Notifications {
  String userID;
  List<String> unreadNotifications;

  List<String> thisBatchOfUnread;
  List<String> notificationList = <String>[];
  Map<String, PunchNotification> allNotifications = {};

  void parseNotifications(Map data) {
    thisBatchOfUnread = <String>[];
    data.forEach((k, v) {
      v.forEach((kk, vv) {
        PunchNotification thisNotif = PunchNotification.readNew(kk, k, vv);
        allNotifications[kk] = thisNotif;
        notificationList.add(kk);
        if (!thisNotif.read) thisBatchOfUnread.add(kk);
      });
    });
  }

  Notifications.getNotifications(
    this.userID,
    void done(),
    void onNew(PunchNotification newNot),
    void onNewList(List<PunchNotification> newListNot),
    void returnSS(StreamSubscription s),
  ) {
    AttendancePresenter.getNotifications(userID, (Map data) {
      List<PunchNotification> newNotList = <PunchNotification>[];
      parseNotifications(data);

      if (unreadNotifications == null) {
        unreadNotifications = thisBatchOfUnread;
      } else {
        thisBatchOfUnread.forEach((String s) {
          if (!unreadNotifications.contains(s)) newNotList.add(allNotifications[s]);
          if (!unreadNotifications.contains(s)) unreadNotifications.add(s);
        });
      }
      done();
      if (newNotList.length > 0) {
        newNotList.length == 1 ? onNew(newNotList[0]) : onNewList(newNotList);
      }
    }, returnSS);
  }
}

class PunchNotification {
  String message;
  String eventID;
  String notificationID;
  int time;
  bool read;

  PunchNotification.readNew(this.notificationID, this.eventID, Map data) {
    message = data['message'];
    time = data['time'];
    read = data['read'];
  }
}

class Calendar {
  String userID;
  List<String> calendarEvents;

  Calendar.init();

  void setUserID(String uid) {
    userID = uid;
  }

  void cancelEventAttendance(String eventID, String reason, void attendanceCancelled()) {
    AttendancePresenter.setAttendanceCancel(eventID, reason, userID, (Map data) {
      calendarEvents.remove(eventID);
      attendanceCancelled();
    });
  }

  void getFirebase(void calendarRetrieved(List<String> aa)) {
    AttendancePresenter.getCalendar(userID, (Map data) {
      calendarRetrieved(parseCalendar(data));
    });
  }

  List<String> parseCalendar(Map data) {
    calendarEvents = <String>[];
    data.forEach((k, v) {
      if (v) calendarEvents.add(k);
    });
    return calendarEvents;
  }
}

class Attendees {
  String eventID;
  Map<String, Attendance> eventAttendees = {};
  List<String> registeredAttendees;
  List<String> checkedInAttendees;
  List<String> feedbackAttendees;
  List<String> checkedOutAttendees;
  List<String> cancelledAttendees;
  Map<String, Question> eventQuestions = {};

//  void voteQuestion(String questionid, String userid, void done()) {
//    AttendancePresenter.setVote(eventID, questionid, userid, (Map data) {
//      eventQuestions[questionid].votes = readVotes(data);
//      done();
//    });
//  }
  void voteQuestion(String questionid, String userid, void done()) {
    AttendancePresenter.setVote(eventID, questionid, userid, done);
  }

  void getQuestions(void onData(Map<String, Question> questions), void returnSS(StreamSubscription s)) {
    AttendancePresenter.getQuestions(
      eventID,
      (Map data) {
        readQuestions(data);
        onData(eventQuestions);
      },
      returnSS,
    );
  }

  Attendees.createByEventID(String eid) {
    eventID = eid;
  }

  int readVotes(Map data) {
    List<String> votes = <String>[];
    data.forEach((s, ss) {
      votes.add(s);
    });
    return votes.length;
  }

  void readQuestions(Map data) {
    if (data != null) {
      data.forEach((k, v) {
        eventQuestions[k] = Question.retrieveQuestion(k, v);
        eventQuestions[k].votes = v['Votes'] == null ? 0 : readVotes(v['Votes']);
      });
    }
  }

  void getFirebase(void attendeesRetrieved()) {
    AttendancePresenter.getAttendance(eventID, (Map data) {
      parseAttendees(data);
      attendeesRetrieved();
    });
  }

  void checkIn(String userKey, void checkInResult(bool r)) {
    AttendancePresenter.setAttendance(true, eventID, userKey, (Map data) {
      registeredAttendees.remove(userKey);
      checkedInAttendees.add(userKey);
      eventAttendees[userKey].checkIn();
      checkInResult(data['Status']);
    });
  }

  void parseAttendees(Map data) {
    registeredAttendees = <String>[];
    checkedInAttendees = <String>[];
    checkedOutAttendees = <String>[];
    feedbackAttendees = <String>[];
    cancelledAttendees = <String>[];
    if (data != null) {
      data.forEach((k, v) {
        Attendance newAttendee = Attendance.parseAttendance(eventID, v, k);
        eventAttendees[k] = newAttendee;
        if (newAttendee.cancelled) {
          cancelledAttendees.add(k);
        } else if (newAttendee.checkedOut) {
          checkedOutAttendees.add(k);
        } else if (newAttendee.feedback) {
          feedbackAttendees.add(k);
        } else if (newAttendee.checkedIn) {
          checkedInAttendees.add(k);
        } else {
          registeredAttendees.add(k);
        }
      });
    }
  }
}

class Attendance {
  String eventID;
  String userKey;
  String name;
  bool feedback = false;
  bool registered = false;
  bool checkedIn = false;
  bool checkedOut = false;
  bool cancelled = false;

  bool isOngoing = true;
  bool canSendFeedback = false;
  bool canAskQuestions = false;
  String cancelledReason;

  Attendance.newAttendance(this.userKey);

  Attendance.parseAttendance(this.eventID, Map data, this.userKey) {
    readAttendance(data);
  }

  void setName(String name) {
    this.name = name;
  }

  void checkIn() {
    checkedIn = true;
  }

  void askQuestion(String question, void questionSubmitted()) {
    ParticipationPresenter.setEventQuestion(eventID, userKey, name, question, questionSubmitted);
  }

  void sendFeedback(List<Response> feedback, void feedbackSubmitted()) {
    ParticipationPresenter.setEventAttendeeFeedback(eventID, userKey, name, feedback, () {
      AttendancePresenter.setFeedback(eventID, userKey, (Map data) {
        readAttendance(data);
        canSendFeedback = false;
        feedbackSubmitted();
      });
    });
  }

  void readAttendance(Map data) {
    if (data.containsKey('Reason')) {
      cancelled = true;
      cancelledReason = data['Reason'];
    } else {
      checkedIn = data['Status'] == null ? false : data['Status'];
      feedback = data['Feedback'] == null ? false : data['Feedback'];
      registered = true;
    }
  }

  void setEventID(String eventID) {
    this.eventID = eventID;
  }

  void setAttendance(void attendanceSet()) {
    AttendancePresenter.setAttendance(false, eventID, userKey, (Map data) {
      readAttendance(data);
      attendanceSet();
    });
  }

  void setAttendanceCancel(String reason, void attendanceCancelled()) {
    AttendancePresenter.setAttendanceCancel(eventID, reason, userKey, (Map data) {
      readAttendance(data);
      attendanceCancelled();
    });
  }

  void setTime(PunchDate end, bool canAsk) {
    if (checkedIn && !feedback && DateTime.now().isAfter(end.datetime.subtract(Duration(minutes: 30)))) {
      canSendFeedback = true;
    }
    if (canAsk = true && DateTime.now().isBefore(end.datetime.add(Duration(minutes: 30)))) {
      canAskQuestions = true;
    }
    if (DateTime.now().isAfter(end.datetime)) {
      isOngoing = false;
    }
  }
}
