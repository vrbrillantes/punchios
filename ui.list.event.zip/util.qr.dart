import 'package:qr_reader/qr_reader.dart';
import 'package:qr_flutter/qr_flutter.dart';
import 'package:flutter/material.dart';

class QRGenerator {
  static Widget attendeeEventQR({String eventID, String userKey}) {
    return QRBuild("CA|$userKey|$eventID");
  }
}

class QRActions {
  static void scanBoardingPass(void returnCode(String s), void wrongQR()) {
    scanQR(
      qrType: "BP",
      returnCode: (List<String> s) {
        returnCode(s[1]);
      },
      wrongQR: wrongQR,
    );
  }

  static void scanCheckInSelf({String eventID, void returnCode(String s), void wrongQR()}) {
    scanQR(
      qrType: "CS",
      returnCode: (List<String> s) {
        eventID != s[2] ? wrongQR() : returnCode(s[1]);
      },
      wrongQR: wrongQR,
    );
  }

  static void scanCheckInAttendee({String eventID, void returnCode(String s), void wrongQR()}) {
    scanQR(
      qrType: "CA",
      returnCode: (List<String> s) {
        eventID != s[2] ? wrongQR() : returnCode(s[1]);
      },
      wrongQR: wrongQR,
    );
  }

  static void scanQR({String qrType, void returnCode(List<String> s), void wrongQR(), also = "any"}) {
    scanEventQr((String qrCode) {
      List<String> qrCodeArray = qrCode.split("|");
      qrCodeArray[0] == qrType ? returnCode(qrCodeArray) : wrongQR();
    });
  }

  static void scanEventQr(void returnCode(String s)) async {
    String barcode = await QRCodeReader()
        .setAutoFocusIntervalInMs(200) // default 5000
        .setForceAutoFocus(true) // default false
        .setTorchEnabled(true) // default false
        .setHandlePermissions(true) // default true
        .setExecuteAfterPermissionGranted(true) // default true
        .scan();
    returnCode(barcode != null ? barcode : "");
  }
}

class QRBuild extends StatelessWidget {
  QRBuild(this.payload);

  final String payload;

  @override
  Widget build(BuildContext context) {
    return QrImage(data: payload, size: 200.0);
  }
}
