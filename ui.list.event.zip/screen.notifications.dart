import 'package:flutter/material.dart';
import 'ui.util.dart';
import 'ui.backdrop.dart';
import 'model.feedback.dart';
import 'model.attendance.dart';
import 'ui_starrating.dart';

class ScreenNotifications extends StatelessWidget {
  ScreenNotifications({this.notifications, this.allNotifications});

  final List<String> notifications;
  final Map<String, PunchNotification> allNotifications;

  @override
  Widget build(BuildContext context) {
    return ScreenNotificationsState(notifications: notifications, allNotifications: allNotifications);
  }
}

class ScreenNotificationsState extends StatefulWidget {
  ScreenNotificationsState({this.notifications, this.allNotifications});

  final Map<String, PunchNotification> allNotifications;
  final List<String> notifications;

  @override
  _ScreenNotificationsBuild createState() => _ScreenNotificationsBuild(notifications: notifications, allNotifications: allNotifications);
}

class _ScreenNotificationsBuild extends State<ScreenNotificationsState> {
  _ScreenNotificationsBuild({this.notifications, this.allNotifications});

  final Map<String, PunchNotification> allNotifications;
  final List<String> notifications;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    List<PunchNotification> notificationsMap = notifications.map<PunchNotification>((String s) {
      return allNotifications[s];
    }).toList();

    notificationsMap.sort((b, a) => a.time.compareTo(b.time));
    return Theme(
        data: ThemeData(
          unselectedWidgetColor: AppColors.appGreyscalePlus,
        ),
        child: Stack(
          children: <Widget>[
            Backdrop2(),
            Scaffold(
              backgroundColor: const Color(0x00000000),
              appBar: AppBar(
                leading: IconButton(icon: Icon(Icons.keyboard_arrow_left), onPressed: () => Navigator.pop(context)),
                backgroundColor: AppColors.appColorBackground,
                title: Text('Notifications', style: AppTextStyles.appbarTitle),
              ),
              body: SingleChildScrollView(
                child: Column(
                  children: notificationsMap.map<Widget>((PunchNotification notif) {
                    return Card(
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
                      margin: EdgeInsets.symmetric(horizontal: 20.0, vertical: 10.0),
                      child: Padding(
                        padding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                        child: Row(
                          children: <Widget>[Expanded(child: Text(notif.message, style: AppTextStyles.eventDetailsGrey))],
                        ),
                      ),
                    );
                  }).toList(),
                ),
              ),
            ),
          ],
        ));
  }
}
