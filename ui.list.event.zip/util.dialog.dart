import 'package:flutter/material.dart';
import 'ui.util.dart';
import 'util.customdialog.dart';

class GenericDialogGenerator {
  GenericDialogGenerator.init(this.buildContext);

  final BuildContext buildContext;

  String registeredString(String eventName) {
    return "Thank you for registering to $eventName";
  }

  String checkedInString = "You're checked-in";
  String checkedInAttendeeString = "Successfully scanned attendee";
  String feedbackSubmittedString = "Thank you for your feedback";
  String feedbackAlreadySubmittedString = "Feedback already submitted";
  String attendanceCancelString = "Cancel registration?";
  String questionSubmittedString = "Your question has been submitted";
  String notifSubmittedString = "Your broadcast message has been sent";
  String attendanceCancelConfirmString = "Your registration is cancelled";
  String saveEventString = "Save event for offline?";
  String interestedEventString = "Interested in this event?";
  String removeEventString = "Remove event for offline?";
  String collabAddedString = "Event collaborator added";
  String collabAskRemoveString = "Remove collaborator?";
  String wrongQRString = "QR is invalid";
  String collabRemovedString = "Event collaborator removed";
  String profileUpdatedString = "Profile updated";
  String profileCheckDetailsString = "Check profile information";

  List<String> collabScreen(String eventName) {
    return <String>[
      eventName,
      'Email of collaborator',
      'Please limit to 1 email at a time',
      'Add collaborator',
    ];
  }

  List<String> askQuestionString(String eventName) {
    return <String>[
      eventName,
      'What is your question?',
      'Question',
      'Submit',
    ];
  }

  List<String> cancelString(String eventName) {
    return <String>[
      eventName,
      'Can you provide your reason for not attending?',
      'Please provide your reason',
      'Cancel',
    ];
  }

  List<String> broadcastString(String eventName) {
    return <String>[
      eventName,
      'What is your message?',
      'Message',
      'Broadcast',
    ];
  }

//
//  static void confirmProduct(BuildContext context, VoidCallback onPressed) {
//    choiceDialog(context, confirmProductString, onYes: onPressed);
//  }

//  void saveEvent(VoidCallback onPressed) {
//    choiceDialog(saveEventString, onYes: onPressed);
//  }
//
//  void cancelRegistration(VoidCallback onPressed) {
//    choiceDialog(attendanceCancelString, onYes: onPressed);
//  }
//
//  void removeSavedEvent(VoidCallback onPressed) {
//    choiceDialog(removeEventString, onYes: onPressed);
//  }

  void confirmDialog(String message, {void onYes()}) {
    void onPressed() {
      Navigator.pop(buildContext);
      onYes();
    }

    showDialog(
      barrierDismissible: false,
      context: buildContext,
      builder: (BuildContext context) {
        return GenericDialog(context, message, onPressed);
      },
    );
  }

  void choiceDialog(String message, {VoidCallback onYes, VoidCallback onNo}) {
    void onPressed(bool b) {
      Navigator.pop(buildContext);
      b ? onYes() : onNo();
    }

    showDialog(
      barrierDismissible: false,
      context: buildContext,
      builder: (BuildContext context) {
        return GenericChoiceDialog(context, message, onPressed);
      },
    );
  }
}

class GenericDialog extends StatelessWidget {
  GenericDialog(this.context, this.message, this.onPressed);

  final BuildContext context;
  final String message;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return CustomAlertDialog(
      content: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            Image.asset(
              'images/success@2x.png',
              height: 60,
            ),
            Padding(
              padding: EdgeInsets.symmetric(vertical: 26),
              child: Column(crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                Text(message, style: AppTextStyles.eventTitle),
                SizedBox(height: 16),
                Text("See the sessions you’ve signed up for on the main event page.", style: AppTextStyles.dialogDescription),
              ]),
            ),
            PunchFlatRaisedButton(action: onPressed, label: 'Done', padded: false),
          ],
        ),
      ),
//      actions: <Widget>[
//        Row(
//          children: <Widget>[
//            PunchFlatRaisedButton(
//              action: onPressed,
//              label: 'Done',
//              expanded: false,
//            ),
//          ],
//        )
//      ],
    );
    return AlertDialog(
      title: Text(message, style: AppTextStyles.labelRegular),
      actions: <Widget>[
        PunchFlatRaisedButton(action: onPressed, label: 'Done', expanded: false),
      ],
    );
  }
}

class GenericChoiceDialog extends StatelessWidget {
  GenericChoiceDialog(this.context, this.message, this.onPressed);

  final void Function(bool) onPressed;
  final BuildContext context;
  final String message;

  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      title: Text(message, style: AppTextStyles.labelRegular),
      actions: <Widget>[
        PunchFlatButton(action: () => onPressed(false), label: 'No', expanded: false),
        PunchFlatButton(action: () => onPressed(true), label: 'Yes', expanded: false),
      ],
    );
  }
}
