import 'package:intl/intl.dart';
import 'package:flutter/material.dart';
class PunchTime {
  int hour;
  int minute;

//  ItemTime.convertDateTimeSlot(String s) {
//    DateTime parsed = DateFormat("MMMdjm").parse(s);
//    hour = int.parse( DateFormat.H().format(parsed));
//    minute = int.parse( DateFormat.m().format(parsed));
//  }
  PunchTime.convertTimeSlot(String s) {
    DateTime parsed = DateFormat("jm").parse(s);
    hour = int.parse( DateFormat.H().format(parsed));
    minute = int.parse( DateFormat.m().format(parsed));
  }
}
class PunchDate {
  String dateTimeString;
  TimeOfDay timeOfDayString;

  DateTime datetime;
  String longdate;
  String longmonth;
  String shortmonth;
  String longyear;
  String day;
  String weekday;
  String weekshortday;
  String simpleDate;
  String time;
  int hour;
  int minute;
  String dbtime;
  int millis;

  void doOtherFormats() {
    longdate = DateFormat.yMMMMd().format(datetime);
    shortmonth = DateFormat.MMM().format(datetime);
    longmonth = DateFormat.MMMM().format(datetime);
    longyear = DateFormat.y().format(datetime);
    weekday = DateFormat.EEEE().format(datetime);
    weekshortday = DateFormat.E().format(datetime);
    day = DateFormat.d().format(datetime);
    time = DateFormat.jm().format(datetime);
    hour = int.parse( DateFormat.H().format(datetime));
    minute = int.parse( DateFormat.m().format(datetime));
    millis = datetime.millisecondsSinceEpoch;
    dbtime = DateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(datetime);
    simpleDate = "$longmonth $day, $longyear";

  }
  PunchDate.initDate(this.dateTimeString) {
    datetime = DateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS").parse(dateTimeString);
    doOtherFormats();
  }
  PunchDate.initDateLongDate(this.longdate) {
    datetime = DateFormat("MMMM d, y").parse(longdate);
    doOtherFormats();

  }
  PunchDate.initDT(this.datetime) {
    doOtherFormats();

  }

  PunchDate.initDateTime(this.dateTimeString, this.timeOfDayString) {
    datetime = DateFormat("yyyy-MM-dd HH:mm:ss.SSSSSS").parse(dateTimeString);
    datetime = DateFormat("yyyy M d HH mm").parse(datetime.year.toString() + " " + datetime.month.toString() + " " + datetime.day.toString() + " " + timeOfDayString.hour.toString() + " " + timeOfDayString.minute.toString());
    doOtherFormats();

  }
}