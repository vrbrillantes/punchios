import 'package:flutter/material.dart';
import 'model.events.dart';
import 'model.attendance.dart';
import 'model.profile.dart';
import 'ui.backdrop.dart';
import 'dart:async';
import 'ui.list.event.dart';
import 'ui.util.dart';
import 'screen.eventview.dart';
import 'screen.textDialog.dart';
import 'util.dialog.dart';
import 'screen.notifications.dart';
import 'screen.profileview.dart';

class ScreenEvents extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return new ScreenEventsState();
  }
}

class ScreenEventsState extends StatefulWidget {
  @override
  _ScreenEventsBuild createState() => new _ScreenEventsBuild();
}

class _ScreenEventsBuild extends State<ScreenEventsState> {
  Events eventsDB = Events.init();
  Calendar agendaDB = Calendar.init();
  List<String> interestedList = <String>[];
  List<String> showEvents = <String>[];
  List<String> horizontalShowEvents = <String>[];
  Profile profile = Profile.init();
  List<String> pageTitles = <String>['Happening', 'Events I\'m interested in', 'My profile'];
  int _selectedIndex = 0;

  Notifications myNotifications;
  List<String> unreadNotifications = <String>[];
  bool profileSet = false;
  bool editing = false;
  Login newLogin = Login.newLogin();
  GenericDialogGenerator dialog;

  StreamSubscription _subscriptionTodo;

  @override
  void initState() {
    dialog = GenericDialogGenerator.init(context);
    eventsDB.getPrefs((List<String> ls) {
      setState(() {
        interestedList = ls;
      });
    });
    profile.getProfile(processLogin);
    eventsDB.getFirebase(setEvents);
//    LoginFunctions.checkBoardingPass((bool bb) {
//      bb == true ? eventsDB.getBoardingPassEvents(setEvents) : eventsDB.getFirebase(setEvents);
//    }); TODO return functionality
    newLogin.getLoginData(() {
      setState(() {
        profile.profileLogin = newLogin;
        profile.getOnlineProfile((bool s) {
          setState(() {
            profileSet = s;
            editing = !s;
          });
        });
      });
    });
    super.initState();
  }

  @override
  void dispose() {
    if (_subscriptionTodo != null) {
      _subscriptionTodo.cancel();
    }
    super.dispose();
  }

  void setEvents(List<String> ls) {
    setState(() {
      showEvents = ls;
    });
  }

  void processLogin() {
    setState(() {
      agendaDB.setUserID(profile.userKey);
      myNotifications = Notifications.getNotifications(
        profile.userKey,
        () {
          setState(() {
            unreadNotifications = myNotifications.unreadNotifications;
          });
        },
        (PunchNotification not) => dialog.confirmDialog(not.message),
        (List<PunchNotification> notList) => dialog.confirmDialog("You have ${notList.length} new notifications"),
        (StreamSubscription ss) {
          _subscriptionTodo = ss;
        },
      );
      agendaDB.getFirebase(eventsDB.setAttendingEvents);
    });
  }

  void showNotifications() {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => new ScreenNotifications(allNotifications: myNotifications.allNotifications, notifications: unreadNotifications)),
    );
  }
  void showEvent(String s) {
    Navigator.push(
      context,
      MaterialPageRoute(builder: (context) => new ScreenEventView(profile: profile, loadEvent: eventsDB.allEvents[s])),
    );
  }

  void _onItemTapped(int index) {
    setState(() {
      _selectedIndex = index;
      switch (index) {
        case 0:
          horizontalShowEvents = <String>[];
          showEvents = eventsDB.activeEvents;
          break;
        case 1:
          horizontalShowEvents = eventsDB.attendingEvents;
          showEvents = eventsDB.interestedEvents;
          break;
        case 2:
          horizontalShowEvents = <String>[];
          showEvents = <String>[];
          break;
      }
    });
  }

  void onSaveEvent(String s) {
    dialog.choiceDialog(dialog.interestedEventString,
        onYes: () => setState(() {
              eventsDB.interestedEvent(s);
            }));
  }

//  void onLongPress(String s) {
//    switch (_selectedIndex) {
//      case 0:
//        dialog.choiceDialog(dialog.saveEventString,
//            onYes: () => setState(() {
//                  eventsDB.saveEvent(s);
//                }));
//        break;
//      case 1:
//        dialog.choiceDialog(dialog.attendanceCancelString,
//            onYes: () => setState(() {
//                  ScreenTextInit.doThis(
//                      context,
//                      dialog.cancelString('Cancel event'),
//                      (String reason) => agendaDB.cancelEventAttendance(s, reason, () {
//                            setState(() => dialog.confirmDialog(dialog.attendanceCancelConfirmString));
//                          }));
//                }));
//        break;
//      case 2:
//        dialog.choiceDialog(dialog.removeEventString,
//            onYes: () => setState(() {
//                  eventsDB.removeEvent(s);
//                }));
//        break;
//    }
//  }

  void updateProfile(Map<String, String> updateProfile) {
    profile.readEdits(updateProfile);
    profile.setOnlineProfile(() {
      setState(() {
        editing = false;
        dialog.confirmDialog(dialog.profileUpdatedString);
      });
    });
  }

  @override
  Widget build(BuildContext context) {
    return Theme(
        data: ThemeData(
          brightness: Brightness.light,
          platform: Theme.of(context).platform,
        ),
        child: Stack(children: <Widget>[
          Backdrop(),
          DefaultTabController(
            length: 3,
            child: Scaffold(
              appBar: AppBar(
                bottom: TabBar(
                  isScrollable: true,
                  tabs: <Widget>[
                    TabBarPadding(iconD: Icon(Icons.event_note), label: 'All events'),
                    TabBarPadding(iconD: Icon(Icons.event_available), label: 'My events'),
                    TabBarPadding(iconD: Icon(Icons.person), label: 'My profile'),
                  ],
                  onTap: _onItemTapped,
                ),
                backgroundColor: AppColors.appColorMainTransparent,
                automaticallyImplyLeading: false,
                title: Image.asset(
                  'images/logo_punch-main.png',
                  height: 40,
                ),
                actions: <Widget>[
                  IconButton(
                    icon: unreadNotifications.length > 0
                        ? Icon(
                            Icons.notifications,
                            color: AppColors.appAccentYellow,
                          )
                        : Icon(Icons.notifications_none),
                    onPressed: showNotifications,
                  ),
//                  IconButton(
//                    icon: Icon(Icons.apps),
//                    onPressed: () {},
//                  ),
//                  IconButton(
//                    icon: Icon(Icons.search),
//                    onPressed: () {},
//                  ),
                ],
              ),
              backgroundColor: const Color(0x00000000),
//              body: CustomScrollView(
//                slivers: <Widget>[
//                ],
//              ),
              body: _selectedIndex == 2
                  ? CustomScrollView(slivers: <Widget>[
                      editing
                          ? ProfileForm(
                              profile: profile,
                              onError: () => dialog.confirmDialog(dialog.profileCheckDetailsString),
                              onFinished: updateProfile,
                            )
                          : ViewProfile(
                              profile: profile,
                              onPressed: () {
                                setState(() {
                                  editing = true;
                                });
                              }),
                    ])
                  : CustomScrollView(slivers: <Widget>[
                      HorizontalListEvent(
                        title: 'Upcoming events',
                        allEvents: eventsDB.allEvents,
                        showEvents: horizontalShowEvents,
                        onPressed: showEvent,
                        onLongPress: onSaveEvent,
                        interestedList: interestedList,
                      ),
                      ListEvent(
                        title: pageTitles[_selectedIndex],
                        allEvents: eventsDB.allEvents,
                        showEvents: showEvents,
                        onPressed: showEvent,
                        onLongPress: onSaveEvent,
                        interestedList: interestedList,
                      ),
                    ]),
            ),
          ),
        ]));
  }
}
