import 'model.date.dart';
import 'model.boardingpass.dart';
import 'util.firebase.dart';
import 'util.preferences.dart';
import 'model.profile.dart';

AppPreferences prefs = AppPreferences.newInstance();

class EventPresenter {
  static void getEvents(void eventsRetrieved(Map data)) {
    FirebaseMethods.getEventsByActiveStatus((Map data) {
      eventsRetrieved(data);
    });
  }

  static void getEventByEventID(String s, void eventsRetrieved(Map data)) {
    FirebaseMethods.getEventByEventID(s, (Map data) {
      eventsRetrieved(data);
    });
  }

  static void sendNotification(String eid, String m, void done()) {
    FirebaseMethods.setAttendeeNotificationByEventID(eid, m, done);
  }

  static void getCollaborators(String eid, void done(Map data)) {
    FirebaseMethods.getEventCollaboratorsByEventID(eid, done);
  }

  static void getLinks(String eid, void done(Map data)) {
    FirebaseMethods.getEventLinksByEventID(eid, done);
  }

  static void removeCollaborator(String eid, String uid, void done(Map data)) {
    FirebaseMethods.setEventCollaborator(eid, uid, false, done);
  }

  static void setCollaborator(String eid, String uid, String email, void done(Map data)) {
    FirebaseMethods.setEventCollaborator(eid, uid, true, done, e: email);
  }

  static void saveEvent(Event ee, void onWrite(bool b)) {
    prefs.initInstance(() {
      prefs.setStringEncode(ee.eventKey, ee.eventMap, onWrite);
    });
  }

  static void getEvent(String s, void done(Map v)) {
    prefs.initInstance(() {
      prefs.getStringDecode(s, done, () {});
    });
  }

  static void getSavedEvents(void done(Map v)) {
    prefs.initInstance(() {
      prefs.getStringDecode('savedEvents', done, () {});
    });
  }

  static void getInterestedEvents(void done(Map v)) {
    prefs.initInstance(() {
      prefs.getStringDecode('savedInterestedEvents', done, () {});
    });
  }

  static void saveEvents(Map v, void onWrite(bool b)) {
    prefs.initInstance(() {
      prefs.setStringEncode('savedEvents', v, onWrite);
    });
  }

  static void saveInterestedEvents(Map v, void onWrite(bool b)) {
    prefs.initInstance(() {
      prefs.setStringEncode('savedInterestedEvents', v, onWrite);
    });
  }
}

class Events {
  Map<String, Event> allEvents = {};
  Map<String, String> savedEventsList = {};
  Map<String, String> interestedEventsList = {};
  List<String> activeEvents = <String>[];
  List<String> savedEvents = <String>[];
  List<String> interestedEvents = <String>[];
  List<String> boardingPassEvents = <String>[];
  List<String> attendingEvents = <String>[];
  List<String> createdEvents;

  Events.init();

  void setAttendingEvents(List<String> ae) {
    attendingEvents = ae;
  }

  void saveEvent(String ee) {
    savedEventsList[ee] = allEvents[ee].dateCreated;
    allEvents[ee].isSaved = true;
    savedEvents.add(ee);
    EventPresenter.saveEvents(savedEventsList, (bool b) {
      if (b) EventPresenter.saveEvent(allEvents[ee], (bool bb) {});
    });
  }

  void interestedEvent(String ee) {
    interestedEventsList[ee] = allEvents[ee].dateCreated;
    allEvents[ee].isInterested = true;
    interestedEvents.add(ee);
    EventPresenter.saveInterestedEvents(interestedEventsList, (bool b) {
      if (b) EventPresenter.saveEvent(allEvents[ee], (bool bb) {});
    });
  }

  void removeEvent(String ee) {
    savedEventsList.remove(ee);
    allEvents[ee].isSaved = false;
    savedEvents.remove(ee);
    EventPresenter.saveEvents(savedEventsList, (bool b) {
//      if (b) EventPresenter.saveEvent(allEvents[ee], (bool bb) {});
    });
  }

  void getPrefs(void showInterested(List<String> ls)) {
    EventPresenter.getSavedEvents((Map<dynamic, dynamic> v) {
      v.forEach((k, vvv) {
        savedEventsList[k] = vvv;
        EventPresenter.getEvent(k, (Map vv) => addEvent(k, vv, saved: true));
      });
    });
    EventPresenter.getInterestedEvents((Map<dynamic, dynamic> v) {
      if (v != null) {
        v.forEach((k, vvv) {
          interestedEventsList[k] = vvv;
          interestedEvents.add(k);
        });
        showInterested(interestedEvents);
      }
    });
  }

  void scanEvent() {}

//  void getEventByID(String s) {
//    EventPresenter.getEventByEventID(s, (Map data) {
////      hasBoardingPass();
//    });
//  }

  void getBoardingPassEvents(void hasBoardingPasses(List<String> b)) {
    BoardingPassPresenter.getSavedBoardingPasses((List<dynamic> boardingPasses) {
      boardingPasses.forEach((k) {
        EventPresenter.getEventByEventID(k, (Map vv) {
          addEvent(k, vv, boardingPass: true);
          hasBoardingPasses(boardingPassEvents);
        });
      });
    });
  }

  void getFirebase(void eventsRetrieved(List<String> ee)) {
    EventPresenter.getEvents((Map data) {
      data.forEach(addEvent);
      eventsRetrieved(activeEvents);
    });
  }

  void addEvent(dynamic key, dynamic value, {saved = false, boardingPass = false}) {
    Event newEvent = Event.fromFirebase(key, value, saved);
    if (!allEvents.containsKey(key)) {
      allEvents[key] = newEvent;
    } else {
      if (allEvents[key].dateCreated != newEvent.dateCreated) {
        newEvent.isSaved = allEvents[key].isSaved;
        allEvents[key] = newEvent;
      }
    }
    if (saved == true) savedEvents.add(key);
    if (boardingPass == true) boardingPassEvents.add(key);
    if (!activeEvents.contains(key) && DateTime.now().isBefore(newEvent.end.datetime.add(Duration(days: 3)))) activeEvents.add(key);
  }
}

class EventLink {
  String key;
  String link;
  String name;

  EventLink.newLink(this.key, Map data) {
    link = data['Link'];
    name = data['Name'];
  }
}

class Event {
  final String eventKey;

  bool isToday = false;
  bool canAskQuestions;
  bool userScansQR;
  bool isPublic;
  bool isSaved = false;
  bool isInterested = false;
  String creator;
  String dateCreated;
  EventAudience eventAudience;
  EventDetails eventDetails;
  List<EventLink> eventLinks;
  PunchDate start;
  PunchDate end;
  Map eventMap;
  Map<String, String> collaborators;
  List<String> collaboratorList;

  Event.fromFirebase(this.eventKey, data, bool saved) {
    eventMap = data;
//    isActive = data['Active'];
//    canAskQuestions = data['CanAsk'];
    isSaved = saved;
    isPublic = data['Public'];
    dateCreated = data['DateCreated'] != null ? data['DateCreated'] : DateTime.now().toString();
    end = data['EndDate'] != null ? PunchDate.initDate(data['EndDate']) : PunchDate.initDate(data['StartDate']);
    start = PunchDate.initDate(data['StartDate']);
//    end = PunchDate.initDate(data['EndDate']);
    eventDetails = EventDetails.fromFirebase(data);
//    eventDetails.addInformation(description: data['Description'], venueSpec: data['VenueSpec']);
    if (-12 < DateTime.now().difference(start.datetime).inHours && DateTime.now().difference(start.datetime).inHours < 12) {
      isToday = true;
    }
    print(DateTime.now().difference(start.datetime).inHours.toString() + " DATE TIME" + data['Name']);
  }

  void sendNotif(String message, void questionSubmitted()) {
    EventPresenter.sendNotification(eventKey, message, questionSubmitted);
  }

  void readCollaborators(Map data) {
    collaborators = {};
    collaboratorList = <String>[];
    if (data != null) {
      data.forEach((k, v) {
        collaborators[k] = v;
        collaboratorList.add(v);
      });
    }
  }

  void readLinks(Map data) {
    eventLinks = <EventLink>[];
    if (data != null) {
      data.forEach((k, v) {
        eventLinks.add(EventLink.newLink(k, v));
      });
    }
  }

  void getCollaborators(void onData(List<String> collabs)) {
    EventPresenter.getCollaborators(eventKey, (Map data) {
      readCollaborators(data);
      onData(collaboratorList);
    });
  }

  void removeCollaborator(String email, void onData(List<String> collabs)) {
    EventPresenter.removeCollaborator(eventKey, AccountUtils.getUserKey(email), (Map data) {
      readCollaborators(data);
      onData(collaboratorList);
    });
  }

  void getLinks(void done(List<EventLink> links)) {
    EventPresenter.getLinks(eventKey, (Map data) {
      print("HAS LINKS " + eventKey + " " + data.toString());
      readLinks(data);
      done(eventLinks);
    });
  }

  void addCollaborator(String email, void onData(List<String> collabs)) {
    EventPresenter.setCollaborator(eventKey, AccountUtils.getUserKey(email), email, (Map data) {
      readCollaborators(data);
      onData(collaboratorList);
    });
  }
}

class EventAudience {
  List<String> audienceList;
}

class EventDetails {
  String name;
  String shortDescription = "MM";
  String venue;
  String venueSpec = "HH";
  String banner;
  String longDescription;

  EventDetails.fromFirebase(Map data) {
    name = data['Name'];
    venue = data['Venue'];
    banner = data['Banner'];
    longDescription = data['Description'] != null ? data['Description'] : "";
  }

  void addInformation({String description, String venueSpec, String brief}) {
    this.longDescription = description;
    this.venueSpec = venueSpec;
    this.shortDescription = brief;
  }
}
