import 'dart:async';
import 'dart:io' show Platform;
import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_messaging/firebase_messaging.dart';
import 'model.profile.dart';
import 'util.preferences.dart';
import 'model.boardingpass.dart';

final FirebaseAuth _auth = FirebaseAuth.instance;
final FirebaseMessaging _firebaseMessaging = FirebaseMessaging();
final GoogleSignIn _googleSignIn = new GoogleSignIn();

AppPreferences prefs = AppPreferences.newInstance();

class LoginFunctions {
  static Login myLogin = Login.newLogin();

  Future<void> handleSignIn() async {
    try {
      await _googleSignIn.signOut();
      await _googleSignIn.signIn();
    } catch (error) {
      print(error);
    }
  }

  void checkBoardingPass(void hasBoardingPasses(bool b)) {
    BoardingPassPresenter.getSavedBoardingPasses((List<dynamic> boardingPasses) {
      hasBoardingPasses(boardingPasses.length > 0 ? true : false);
    });
  }

  void saveBoardingPass(String s, void saved(bool b)) async {
    BoardingPassPresenter.getSavedBoardingPasses((List<dynamic> boardingPasses) {
      boardingPasses.add(s);
      BoardingPassPresenter.saveBoardingPasses(boardingPasses, saved);
    });
  }

  void firebaseAuth(GoogleSignInAccount cu, void done(FirebaseUser fu)) async {
    Profile.saveCredentials(_googleSignIn);
    final GoogleSignInAuthentication googleAuth = await cu.authentication;
    final AuthCredential credential = GoogleAuthProvider.getCredential(
      accessToken: googleAuth.accessToken,
      idToken: googleAuth.idToken,
    );
    FirebaseUser user = await _auth.signInWithCredential(credential);
    done(user);
  }

  LoginFunctions.initSignIn(void loggedIn(), void noAccount()) {
    _googleSignIn.onCurrentUserChanged.listen((GoogleSignInAccount acc) => processGSI(
          acc,
          () {
            loggedIn();
            setupFCM();
          },
          noAccount,
        ));
    _googleSignIn.signInSilently().then((GoogleSignInAccount acc) => processGSI(acc, loggedIn, noAccount));
  }

  void processGSI(GoogleSignInAccount account, void loggedIn(), void noAccount()) {
    if (account != null) {
      firebaseAuth(account, (FirebaseUser fu) => processFirebaseUser(fu, loggedIn));
    } else {
      noAccount();
    }
  }

  void processFirebaseUser(FirebaseUser fu, void done()) {
    myLogin.getLoginData(() {
      if (myLogin.fcm == null) {
        setupToken((String token) {
          myLogin.saveData(fu.email, fu.uid, token);
          done();
        });
      } else {
        done();
      }
    });
  }

  static void logOut() {
    _googleSignIn.signOut();
    myLogin.deleteLogin();
  }

  static void setupToken(void done(String s)) {
    _firebaseMessaging.getToken().then((String newToken) {
      assert(newToken != null);
      done(newToken);
    });
  }

  void setupFCM() {
    if (Platform.isIOS) iOS_Permission();
    _firebaseMessaging.configure(
      onMessage: (Map<String, dynamic> message) {
        print("onMessage: $message");
      },
      onLaunch: (Map<String, dynamic> message) {
        print("onLaunch: $message");
      },
      onResume: (Map<String, dynamic> message) {
        print("onResume: $message");
      },
    );
  }

  static void iOS_Permission() {
    _firebaseMessaging.requestNotificationPermissions(IosNotificationSettings(sound: true, badge: true, alert: true));
    _firebaseMessaging.onIosSettingsRegistered.listen((IosNotificationSettings settings) {
      print("Settings registered: $settings");
    });
  }
}
