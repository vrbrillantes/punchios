import 'util.preferences.dart';
import 'util.firebase.dart';

class ProfilePresenter {
  static AppPreferences prefs = AppPreferences.newInstance();

  static void saveProfile(Profile p) async {
    prefs.initInstance(() {
      prefs.setStrings({'email': p.email, 'name': p.name, 'photo': p.photo});
    });
  }

  static void getMyOldAccount(String userKey, void onData(Map data)) {
    FirebaseMethods.getMyAccountOld(userKey, onData);
  }

  static void getMyAccount(String uuid, void onData(Map data)) {
    FirebaseMethods.getMyAccount(uuid, onData);
  }

  static void setMyAccount(String uuid, Map data, void onData()) {
    FirebaseMethods.setMyAccount(uuid, data, onData);
  }

  static void getProfile(void done(Map<String, String> data)) {
    prefs.initInstance(() {
      prefs.getStrings(['email', 'name', 'photo'], done);
    });
  }
}

class LoginPresenter {
  static AppPreferences prefs = AppPreferences.newInstance();

  static void getLoginData(void done(Map<String, String> data)) {
    prefs.initInstance(() {
      prefs.getStrings(['fcm', 'username', 'uuid'], done);
    });
  }

  static void saveStrings(Map<String, String> data) {
    prefs.initInstance(() {
      prefs.setStrings(data);
    });
  }

  static void saveUsename(String username) {
    prefs.initInstance(() {
      prefs.setString('username', username);
    });
  }

  static void saveUUID(String username) {
    prefs.initInstance(() {
      prefs.setString('uuid', username);
    });
  }

  static void saveFCMToken(String fcmToken) {
    prefs.initInstance(() {
      prefs.setString('fcm', fcmToken);
    });
  }
}

class Login {
  String fcm;
  String username;
  String uuid;

  Login.newLogin();

  void getLoginData(void done()) {
    LoginPresenter.getLoginData((Map data) {
      fcm = data['fcm'];
      username = data['username'];
      uuid = data['uuid'];
      done();
    });
  }

  void setLoginData(Map<String, String> data) {}

  void saveData(String username, String uuid, String token) {
    LoginPresenter.saveStrings({'fcm': token, 'uuid': uuid, 'username': username});
  }

  void deleteLogin() {
    //TODO delete login
  }
}

class Profile {
  String photo;
  bool set = false;
  String name;
  String email;
  String firstName;
  String lastName;
  String userKey;
  String company;
  String group;
  String division;
  String department;
  String idNumber;
  String token;
  Login profileLogin;
  Map<dynamic, dynamic> userMap;

//  Profile.create(this.name, this.email, this.photo, this.userKey);

  Profile.init();

  void getProfile(void done()) {
    ProfilePresenter.getProfile((Map<String, String> data) => setProfileData(data, done));
  }

  void getOnlineProfile(void done(bool s)) {
    ProfilePresenter.getMyAccount(profileLogin.uuid, (Map data) {
      if (data != null) {
        profileFromJson(data);
        done(true);
      } else
        ProfilePresenter.getMyOldAccount(userKey, (Map data2) {
          if (data2 != null) {
            profileFromJson(data2);
            setOnlineProfile(() {
              done(true);
            });
          } else {
            done(false);
          }
        });
    });
  }

  void setOnlineProfile(void done()) {
    updateMap();
    print(profileLogin.uuid + " " + userMap.toString() + " TRAILING");

    ProfilePresenter.setMyAccount(profileLogin.uuid, userMap, done);
  }

  void setProfileData(Map<String, String> data, void done()) {
    email = data['email'];
    name = data['name'];
    photo = data['photo'];
    userKey = AccountUtils.getUserKey(email);
    done();
  }

  Profile.saveCredentials(c) {
    this.name = c.currentUser.displayName;
    this.email = c.currentUser.email;
    this.photo = c.currentUser.photoUrl;
    this.userKey = AccountUtils.getUserKey(c.currentUser.email);
    ProfilePresenter.saveProfile(this);
  }

  void updateMap() {
    if (userMap == null) userMap = {};
    Map<String, String> nameMap = {};
    nameMap['Full'] = name;
    nameMap['First'] = firstName;
    nameMap['Last'] = lastName;
    userMap['Name'] = nameMap;

    userMap['Photo'] = photo;
    userMap['email'] = email;

    userMap['FCMToken'] = profileLogin.fcm;
    userMap['Division'] = division;
    userMap['Group'] = group;
    userMap['ID Number'] = idNumber;
    userMap['Department'] = department;
  }

  void readEdits(Map<String, String> data) {
    firstName = data['First'];
    lastName = data['Last'];
    idNumber = data['ID'];
    group = data['Group'];
    division = data['Division'];
    department = data['Department'];
    name = "$firstName $lastName";
  }

  void profileFromJson(Map data) {
    userMap = data;
    name = data['Name']['Full'];
    firstName = data['Name']['First'];
    lastName = data['Name']['Last'];
    idNumber = data['ID Number'];
    email = data['email'];
    company = data['Company'];
    group = data['Group'];
    division = data['Division'];
    department = data['Department'];
    token = data['FCMToken'];
    photo = data['Photo'];
  }
}

class AccountUtils {
  static String getUserKey(String email) {
    if (email != null) {
      String userKey = email.replaceAll("@", "");
      userKey = userKey.replaceAll(".", "");
      userKey = userKey.replaceAll("-", "");
      userKey = userKey.replaceAll("_", "");
      return userKey;
    }
    return "";
  }
}
