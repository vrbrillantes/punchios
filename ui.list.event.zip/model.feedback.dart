import 'util.firebase.dart';
import 'util.preferences.dart';

class FeedbackPresenter {
  static void getFeedback(String eventID, void feedbackRetrieved(Map data)) {
    FirebaseMethods.getFeedbackQuestionsByEventID(eventID, (Map data) {
      if (data != null) feedbackRetrieved(data);
    });
  }
}

class FeedbackQuestions {
  String eventID;
  List<Question> questionList;

  FeedbackQuestions.fromFirebase(this.eventID, void feedbackRetrieved(List<Question> qq)) {
    FeedbackPresenter.getFeedback(eventID, (Map data) {
      parseFeedback(data);
      feedbackRetrieved(questionList);
    });
  }

  void parseFeedback(Map data) {
    questionList = <Question>[];
    int questionOrder = 0;
    data.forEach((k, v) {
      questionList.add(Question.fromFirebase(k, v, questionOrder));
      questionOrder++;
    });
  }
}

class Response {
  String question;
  String response;
  Map<String, String> responseMap = {};

  Response.newResponse(this.question, this.response) {
    responseMap = {'Q': question, 'R': response};
  }
}

class Question {
  int questionOrder;
  final String key;
  String question;
  String type;
  String longType;
  List<String> choices = <String>[];
  Map<String, bool> boolChoices = {};

  Question.submitButton(this.key) {
    type = "SB";
  }

  Question.fromFirebase(this.key, Map data, int qo) {
    question = data['Q'];
    type = data['T'];
    questionOrder = data['I'] != null ? data['I'] : qo;
    switch (type) {
      case "R":
        longType = "Rating";
        break;
      case "F":
        longType = "Feedback";
        break;
      case "YN":
        choices = [
          "Yes",
          "No",
        ];
        longType = "Yes/No";
        break;
      case "AS":
        choices = [
          "Strongly Agree",
          "Agree",
          "Neutral",
          "Disagree",
          "Strongly Disagree",
        ];
        longType = "Agree Scale";
        break;
      case "RS":
        choices = [
          "Will recommend",
          "Likely to recommended",
          "Will neither recommend nor discourage",
          "Likely to discourage",
          "Will discourage",
        ];
        longType = "Recommend Scale";
        break;
      case "UYS":
        choices = [
          "Wonderful",
          "Surprising",
          "Desired",
          "Expected",
          "Basic",
          "Criminal",
        ];
        longType = "UYS";
        break;
      case "P":
        longType = "Poll";
        parseChoices(data['Choices']);
        break;
      case "MS":
        longType = "Multiple Selection";
        parseChoices(data['Choices']);
        break;
//      case "RK":
//        longType = "Ranking";
//        break;
    }
  }

  void parseChoices(List<dynamic> choiceList) {
    choiceList.forEach((dynamic s) {
      choices.add(s.toString());
    });

    choices.forEach((String s) {
      boolChoices[s] = false;
    });
  }
}
