import 'package:flutter/material.dart';
import 'ui.util.dart';

class ScreenTextInit {
  static void doThis(BuildContext c, List<String> labels, void done(String s)) async {
    String reason = await Navigator.push(c, MaterialPageRoute(builder: (context) => ScreenTextDialog(label: labels)));
    if (reason != null) done(reason);
  }
}

class ScreenTextDialog extends StatelessWidget {
  ScreenTextDialog({this.label});

  final List<String> label;

  @override
  Widget build(BuildContext context) {
    return ScreenTextDialogState(label: label);
  }
}

class ScreenTextDialogState extends StatefulWidget {
  ScreenTextDialogState({this.label});

  final List<String> label;

  @override
  _ScreenTextDialogBuild createState() => _ScreenTextDialogBuild(label: label);
}

class _ScreenTextDialogBuild extends State<ScreenTextDialogState> {
  _ScreenTextDialogBuild({this.label});

  void submitText(String s) {
    if (s != "") Navigator.pop(context, s);
  }

  final List<String> label;
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  @override
  Widget build(BuildContext context) {
    final FormState form = _formKey.currentState;
    return Theme(
      data: ThemeData(),
      child: Scaffold(
        appBar: AppBar(
          leading: IconButton(icon: Icon(Icons.keyboard_arrow_left), onPressed: () => Navigator.pop(context)),
          backgroundColor: AppColors.appColorBackground,
          title: Text(label[0], style: AppTextStyles.appbarTitle),
        ),
        body: Form(
          key: _formKey,
          child: SingleChildScrollView(
            padding: EdgeInsets.all(32.0),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              mainAxisSize: MainAxisSize.max,
              children: <Widget>[
                Text(label[1], style: AppTextStyles.titleStyle),
                TextFormField(
                  decoration: InputDecoration(
                    border: OutlineInputBorder(),
                    hintText: label[2],
                  ),
                  onSaved: submitText,
                ),
                PunchRaisedButton(
                  action: () => form.save(),
                  label: label[3],
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
