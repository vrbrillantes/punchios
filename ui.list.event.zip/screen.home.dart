import 'package:flutter/material.dart';
import 'screen.login.dart';
import 'screen.events.dart';

class ScreenHome extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return ScreenHomeState();
  }
}

class ScreenHomeState extends StatefulWidget {
  @override
  _ScreenHomeBuild createState() => _ScreenHomeBuild();
}

class _ScreenHomeBuild extends State<ScreenHomeState> with SingleTickerProviderStateMixin {
  bool isLoggedIn = false;


  @override
  void initState() {
    super.initState();
  }

  void loggedIn(bool li) {
    setState(() {
      isLoggedIn = li;
    });
  }

  void logOut() {
    setState(() {
      isLoggedIn = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: isLoggedIn ? ScreenEvents() : ScreenLogin(onLogIn: loggedIn));
  }
}
