import 'package:flutter/material.dart';
import 'ui.util.dart';
import 'util.login.dart';
import 'util.qr.dart';
import 'ui.backdrop.dart';

class ScreenLogin extends StatelessWidget {
  ScreenLogin({this.onLogIn});

  final void Function(bool) onLogIn;

  @override
  Widget build(BuildContext context) {
    return new ScreenLoginState(onLogIn: onLogIn);
  }
}

class ScreenLoginState extends StatefulWidget {
  ScreenLoginState({this.onLogIn});

  final void Function(bool) onLogIn;

  @override
  _ScreenLoginBuild createState() => new _ScreenLoginBuild(onLogIn: onLogIn);
}

class _ScreenLoginBuild extends State<ScreenLoginState> {
  _ScreenLoginBuild({this.onLogIn});

  LoginFunctions loginFunctions;
  bool returnedLogin = false;
  final void Function(bool) onLogIn;

  void loggedIn() async {
    setState(() {
      onLogIn(true);
      returnedLogin = true;
    });
  }

  void notLoggedIn() {
    loginFunctions.checkBoardingPass((bool bb) {
      onLogIn(bb);
    });
    setState(() {
      returnedLogin = true;
    });
  }

  @override
  void initState() {
    super.initState();
    loginFunctions = LoginFunctions.initSignIn(loggedIn, notLoggedIn);
  }

  void login() {
    loginFunctions.handleSignIn();
  }

  void processBoardingPass(String s) {
    loginFunctions.saveBoardingPass(s, (bool s) {
      onLogIn(true);
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: AppColors.appColorBlue,
      body: Stack(
        children: <Widget>[
          Backdrop(),
          Positioned.fill(
            left: 20,
            right: 20,
            child: Column(
              mainAxisSize: MainAxisSize.max,
              mainAxisAlignment: MainAxisAlignment.center,
              children: <Widget>[
                Image.asset('images/logo_punch-main@3x.png'),
                SizedBox(height: 60,),
                PunchRaisedButton(
                  label: "Login",
                  action: returnedLogin ? login : null,
                ),
                PunchRaisedButton(
                  label: "Scan event",
                  action: () => QRActions.scanBoardingPass(processBoardingPass, () {}),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
