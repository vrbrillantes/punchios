import 'package:flutter/material.dart';
import 'model.events.dart';
import 'ui.util.dart';

import 'package:url_launcher/url_launcher.dart';


class NewBanner extends StatelessWidget {
  NewBanner(this.loadEvent, this.onShowInterest, this.isInterested); // modified
  final Event loadEvent; // modified

  final bool isInterested;
  final VoidCallback onShowInterest;
  @override
  Widget build(BuildContext context) {
    return Card(
      clipBehavior: Clip.antiAlias,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
      margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
      child: Stack(
        children: <Widget>[
          SizedBox(height: 120),
          Positioned(
            right: 16,
            top: 16,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(8.0),
              child: Hero(
                tag: loadEvent.eventKey,
                child: Image.network(loadEvent.eventDetails.banner, height: 90.0, width: 90.0, fit: BoxFit.cover),
              ),
            ),
          ),
          Positioned(
            top: 16,
            left: 16,
            right: 132,
            child: EventDetails(loadEvent: loadEvent),
          ),
          Positioned(
            bottom: 16,
            left: 16,
            child: EventIcons(interestedval: isInterested, onShowInterest: onShowInterest),
          ),
        ],
      ),
    );
  }
}

class EventIcons extends StatelessWidget {
  EventIcons({this.onShowInterest, this.space = true, this.cal = false, this.calv = false, this.interested = false, this.interestedval = false});

  final bool space;
  final bool cal;
  final bool calv;
  final bool interested;
  final bool interestedval;
  final VoidCallback onShowInterest;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisAlignment: space ? MainAxisAlignment.spaceEvenly : MainAxisAlignment.start,
      children: <Widget>[
        SizedBox(width: space ? 0 : 8),
        InkWell(
          onTap: () {},
          child: Row(
            children: <Widget>[
              Icon(Icons.share, size: 14, color: AppColors.appGreyBlue),
              Text('Share', style: AppTextStyles.bannerActions),
            ],
          ),
        ),
        SizedBox(width: 8),
//        InkWell(
//          onTap: () {},
//          child: Row(
//            children: <Widget>[
//              Icon(Icons.event_note, size: 14, color: calv ? AppColors.appAccentYellow : AppColors.appGreyBlue),
//              Text('Add to calendar', style: calv ? AppTextStyles.bannerActionsClicked : AppTextStyles.bannerActions),
//            ],
//          ),
//        ),
        InkWell(
          onTap: onShowInterest,
          child: Row(
            children: <Widget>[
              Icon(Icons.star, size: 14, color: interestedval ? AppColors.appAccentYellow : AppColors.appGreyBlue),
              Text('Interested', style: interestedval ? AppTextStyles.bannerActionsClicked : AppTextStyles.bannerActions),
            ],
          ),
        ),
      ],
    );
  }
}

class EventDetails extends StatelessWidget {
  EventDetails({this.loadEvent});

  final Event loadEvent;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Text(loadEvent.eventDetails.name, style: AppTextStyles.bannerTitle),
        Text("${loadEvent.start.simpleDate} (${loadEvent.start.weekshortday})", style: AppTextStyles.bannerDate),
        Text(loadEvent.eventDetails.shortDescription, style: AppTextStyles.bannerDescription),
      ],
    );
  }
}

class EventBanner extends StatelessWidget {
  EventBanner({this.loadEvent, this.onLongPress, this.onPressed, this.isInterested}); // modified
  final Event loadEvent; // modified

  final VoidCallback onLongPress;
  final VoidCallback onPressed;
  final bool isInterested;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: NewBanner(loadEvent, onLongPress, isInterested),
      onTap: onPressed,
    );
  }
}

class VerticalBanner extends StatelessWidget {
  VerticalBanner({this.loadEvent, this.onPressed, this.onShowInterest, this.isInterested}); // modified
  final Event loadEvent; // modified

  final VoidCallback onPressed;
  final VoidCallback onShowInterest;
  final bool isInterested;
  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Card(
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
        child: Stack(
          children: <Widget>[
            Positioned(
              left: 0,
              top: 0,
              right: 0,
              height: 152,
              child: Image.network(loadEvent.eventDetails.banner, fit: BoxFit.cover),
            ),
            Positioned(
              left: 0,
              bottom: 0,
              right: 0,
              height: 30,
              child: EventIcons(space: false, interestedval: isInterested, onShowInterest: onShowInterest),
            ),
            Positioned.fill(
              top: 152,
              bottom: 30,
              child: Row(
                children: <Widget>[
                  SizedBox(
                    width: 50,
                    child: Container(
                      color: loadEvent.isToday ? AppColors.appAccentYellow : AppColors.appGreyscalePlus,
                      child: Column(
                        mainAxisSize: MainAxisSize.max,
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: <Widget>[
                          Text(loadEvent.start.shortmonth, style: AppTextStyles.bannerDateMonth),
                          Text(loadEvent.start.day, style: AppTextStyles.bannerDateDay),
                        ],
                      ),
                    ),
                  ),
                  Expanded(
                    child: Container(padding: EdgeInsets.all(8), child: EventDetails(loadEvent: loadEvent)),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      onTap: onPressed,
    );
  }
}

class VerticalEventsButton extends StatelessWidget {
  VerticalEventsButton({this.onPressed}); // modified

  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      child: Card(
        clipBehavior: Clip.antiAlias,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8.0)),
        child: Stack(
          children: <Widget>[
            Positioned.fill(child: Container(color: AppColors.appAccentPurple)),
            Positioned.fill(child: Image.asset('images/view-all_button.png', fit: BoxFit.cover)),
            Positioned.fill(child: Column(mainAxisAlignment: MainAxisAlignment.center, children: <Widget>[Text('View all', style: AppTextStyles.styleWhiteBold(16),)],)),
          ],
        ),
      ),
      onTap: onPressed,
    );
  }
}

//class MiniBanner extends StatelessWidget {
//  MiniBanner({this.loadEvent, this.onPressed}); // modified
//  final Event loadEvent; // modified
//  final VoidCallback onPressed;
//
//  @override
//  Widget build(BuildContext context) {
//    return InkWell(
//      child: Card(
//        clipBehavior: Clip.antiAlias,
//        margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
//        child: Stack(
//          children: <Widget>[
//            Hero(
//              tag: loadEvent.eventKey,
//              child: Image.network(loadEvent.eventDetails.banner, height: 60.0, width: 60.0, fit: BoxFit.cover),
//            ),
//            Positioned.fill(
//              left: 64.0,
//              right: 0,
//              child: Column(
//                mainAxisAlignment: MainAxisAlignment.center,
//                crossAxisAlignment: CrossAxisAlignment.start,
//                children: <Widget>[
//                  Text(loadEvent.eventDetails.name, style: AppTextStyles.titleStyleBlue),
//                  Text(loadEvent.eventDetails.shortDescription, style: AppTextStyles.labelMiniDark),
//                ],
//              ),
//            ),
//          ],
//        ),
//      ),
//      onTap: onPressed,
//    );
//  }
//}

//class LargeBanner extends StatelessWidget {
//  LargeBanner({this.loadEvent, this.onPressed, this.onSave}); // modified
//  final Event loadEvent; // modified
//  final VoidCallback onPressed;
//  final VoidCallback onSave;
//
//  @override
//  Widget build(BuildContext context) {
//    return InkWell(
//      child: Card(
//        clipBehavior: Clip.antiAlias,
//        margin: EdgeInsets.symmetric(horizontal: 16.0, vertical: 8.0),
//        child: Stack(
//          children: <Widget>[
//            SizedBox(
//              height: 250.0,
//            ),
//            Positioned.fill(
//              child: Hero(
//                tag: loadEvent.eventKey,
//                child: Image.network(loadEvent.eventDetails.banner, fit: BoxFit.cover),
//              ),
//            ),
//            Positioned.fill(
//              top: 125.0,
//              child: Container(
//                decoration: BoxDecoration(
//                    gradient: LinearGradient(
//                  begin: Alignment.topCenter,
//                  end: Alignment.bottomCenter,
//                  colors: [
//                    Color.fromARGB(0, 255, 255, 255),
//                    Color.fromARGB(175, 255, 255, 255),
//                    Color.fromARGB(255, 255, 255, 255),
//                  ],
//                )),
//              ),
//            ),
//            Positioned(
//              right: 0,
//              child: Container(
//                padding: EdgeInsets.symmetric(vertical: 8.0, horizontal: 16.0),
//                color: AppColors.appColorBlueAccent,
//                child: Text(
//                  loadEvent.start.shortmonth + " " + loadEvent.start.day,
//                  style: AppTextStyles.labelWhiteMini,
//                ),
//              ),
//            ),
//            Positioned(
//              right: 0,
//              bottom: 0,
//              child: loadEvent.isSaved
//                  ? Icon(Icons.check)
//                  : IconButton(
//                      icon: Icon(Icons.save),
//                      onPressed: onSave,
//                    ),
//            ),
//            Positioned.fill(
//              top: 125.0,
//              left: 16.0,
//              bottom: 16.0,
//              child: Column(
//                mainAxisAlignment: MainAxisAlignment.end,
//                crossAxisAlignment: CrossAxisAlignment.start,
//                children: <Widget>[
//                  Text("BY ISG", style: AppTextStyles.labelMiniBold),
//                  Text(loadEvent.eventDetails.name, style: AppTextStyles.titleStyleBlue),
//                  Text(loadEvent.eventDetails.shortDescription, style: AppTextStyles.labelMiniDark),
//                ],
//              ),
//            ),
//          ],
//        ),
//      ),
//      onTap: onPressed,
//    );
//  }
//}

class EventLabel extends StatelessWidget {
  EventLabel({this.label}); // modified
  final String label; // modified

  @override
  Widget build(BuildContext context) {
    return ListTile(
      title: Text(
        label,
        style: AppTextStyles.eventTitle,
      ),
    );
  }
}

class EventDetailsBar extends StatelessWidget {
  EventDetailsBar({this.loadEvent});

  final Event loadEvent;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          padding: EdgeInsets.symmetric(horizontal: 12.0),
          child: ListTile(
            title: Text("${loadEvent.start.longdate} | ${loadEvent.start.weekday}", style: AppTextStyles.eventDetails),
//            subtitle: Text("${loadEvent.start.time} - ${loadEvent.end.time}"),
            leading: Icon(Icons.event_note),
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 12.0),
          child: ListTile(
            title: Text(loadEvent.eventDetails.venue, style: AppTextStyles.eventDetails),
//            subtitle: Text(loadEvent.eventDetails.venueSpec),
            leading: Icon(Icons.location_on),
          ),
        ),
      ],
    );
  }
}

class SessionDetailsBar extends StatelessWidget {
//  SessionDetailsBar({this.loadEvent, this.eventAttendees});

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          padding: EdgeInsets.symmetric(horizontal: 12.0),
          child: ListTile(
            title: Text('View sessions for this esvent', style: AppTextStyles.eventDetails),
            leading: Icon(Icons.list),
          ),
        ),
      ],
    );
  }
}

class AttendeesDetailsBar extends StatelessWidget {
  AttendeesDetailsBar({this.loadEvent, this.eventAttendees});

  final Event loadEvent;
  final int eventAttendees;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Container(
          padding: EdgeInsets.symmetric(horizontal: 12.0),
          child: ListTile(
            title: Text('Going', style: AppTextStyles.bannerTitle),
          ),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 18.0),
          child: Row(
            children: <Widget>[
              Padding(
                padding: EdgeInsets.all(8),
                child: ClipOval(
                  child:
                      Image.network("https://lh4.googleusercontent.com/-gEK1m_TuetY/AAAAAAAAAAI/AAAAAAAACrk/xKRbizticDI/s96-c/photo.jpg", height: 32),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: ClipOval(
                  child:
                      Image.network("https://lh3.googleusercontent.com/-NQQibIsXQaA/AAAAAAAAAAI/AAAAAAAAAk0/KIZ1QCZpiM4/s96-c/photo.jpg", height: 32),
                ),
              ),
              Padding(
                padding: EdgeInsets.all(8),
                child: ClipOval(
                  child:
                      Image.network("https://lh6.googleusercontent.com/-_Uk8opug3eE/AAAAAAAAAAI/AAAAAAAAASQ/SmYmmvy1uAs/s1337/photo.jpg", height: 32),
                ),
              ),
              eventAttendees > 3 ? Text("${(eventAttendees - 3).toString()} others", style: AppTextStyles.eventDetailsGrey) : SizedBox(),
            ],
          ),
        ),
      ],
    );
  }
}

class RelatedInfoDetailsBar extends StatelessWidget {
  RelatedInfoDetailsBar({this.eventLinks});

  final List<EventLink> eventLinks;

  _launchURL(String url) async {
    if (await canLaunch(url)) {
      await launch(url);
    } else {
      throw 'Could not launch $url';
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.symmetric(horizontal: 18, vertical: 15),
          child: Text('Related content', style: AppTextStyles.bannerTitle),
        ),
        Container(
          padding: EdgeInsets.symmetric(horizontal: 18.0),
          child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: eventLinks.map<Widget>((EventLink e) {
                return InkWell(
                    child:
                        Container(child: Text(e.name, style: AppTextStyles.eventLinks), padding: EdgeInsets.symmetric(horizontal: 12, vertical: 6)),
                    onTap: () => _launchURL(e.link));
              }).toList()),
        ),
      ],
    );
  }
}

//class EventDetailsEdit extends StatelessWidget {
//  EventDetailsEdit({this.loadEvent});
//
//  final Event loadEvent;
//
//  @override
//  Widget build(BuildContext context) {
//    return Column(
//      children: <Widget>[
//        Container(
//          padding: EdgeInsets.symmetric(horizontal: 16.0),
//          child: ListTile(
//            title: Text("${loadEvent.start.longdate} | ${loadEvent.start.weekday}", style: AppTextStyles.titleStyleDark),
//            subtitle: Text("${loadEvent.start.time} - ${loadEvent.end.time}"),
//            leading: Icon(Icons.event_note),
//          ),
//        ),
//        Container(
//          padding: EdgeInsets.symmetric(horizontal: 16.0),
//          child: ListTile(
//            title: Text(loadEvent.eventDetails.venue, style: AppTextStyles.titleStyleDark),
//            subtitle: Text(loadEvent.eventDetails.venueSpec),
//            leading: Icon(Icons.location_on),
//          ),
//        ),
//        Container(
//          padding: EdgeInsets.symmetric(horizontal: 16.0),
//          child: ListTile(
//            title: Text(loadEvent.start.longdate + " | " + loadEvent.start.weekday, style: AppTextStyles.titleStyleDark),
//          ),
//        ),
//      ],
//    );
//  }
//}

class CheckInWidget extends StatelessWidget {
  CheckInWidget({this.qrWidget, this.cancel, this.scanQR});

  final Widget qrWidget;
  final VoidCallback scanQR;
  final VoidCallback cancel;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
      mainAxisSize: MainAxisSize.max,
      children: <Widget>[
        qrWidget,
        PunchRaisedButton(label: "Scan event QR", action: scanQR),
        FlatButton(child: Text('Cancel'), textColor: AppColors.appColorThinkBlue, onPressed: cancel),
      ],
    );
  }
}

class StaticBanner extends StatelessWidget {
  StaticBanner({this.loadEvent}); // modified
  final Event loadEvent; // modified

  @override
  Widget build(BuildContext context) {
    return Hero(
      tag: loadEvent.eventKey,
      child: Image.network(loadEvent.eventDetails.banner, height: 300, fit: BoxFit.cover),
    );
  }
}
