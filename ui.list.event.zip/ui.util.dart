import 'package:flutter/material.dart';
//import 'model.notification.dart';

//class ExpandedButton extends StatelessWidget {
//  ExpandedButton({this.action, this.label});
//
//  final VoidCallback action;
//  final String label;
//
//  @override
//  Widget build(BuildContext context) {
//    return Expanded(
//      child: Padding(
//        padding: EdgeInsets.symmetric(horizontal: 4.0),
//        child: RaisedButton(
//          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10.0)),
//          padding: EdgeInsets.symmetric(vertical: 12.0),
//          color: AppColors.appColorThinkBlue,
//          child: Text(
//            label,
//            style: AppTextStyles.labelWhite,
//          ),
//          onPressed: action,
//        ),
//      ),
//    );
//  }
//}

class PunchRaisedButton extends StatelessWidget {
  PunchRaisedButton({this.action, this.label, this.expanded = true});

  final VoidCallback action;
  final String label;
  final bool expanded;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: expanded ? double.infinity : null,
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: 8, horizontal: 18),
        child: RaisedButton(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6.0)),
          padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 0.0),
          color: AppColors.appColorAccent,
          child: Text(label, style: AppTextStyles.styleWhiteBold(18)),
          onPressed: action,
        ),
      ),
    );
  }
}

class PunchFlatRaisedButton extends StatelessWidget {
  PunchFlatRaisedButton({this.action, this.label, this.expanded = true, this.padded = true});

  final VoidCallback action;
  final String label;
  final bool padded;
  final bool expanded;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: expanded ? double.infinity : null,
      child: Padding(
        padding: EdgeInsets.symmetric(vertical: padded ? 8 : 0, horizontal: padded ? 18 : 0),
        child: FlatButton(
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6.0)),
          padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 0.0),
          color: AppColors.appColorAccent,
          child: Text(label, style: AppTextStyles.styleWhiteBold(18)),
          onPressed: action,
        ),
      ),
    );
  }
}

class PunchFlatButton extends StatelessWidget {
  PunchFlatButton({this.action, this.label, this.expanded = true});

  final VoidCallback action;
  final String label;
  final bool expanded;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: expanded ? double.infinity : null,
      child: FlatButton(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        onPressed: action,
        padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 32.0),
        child: Text(label, style: AppTextStyles.labelWhite),
      ),
    );
  }
}

class PunchOSFlatButton extends StatelessWidget {
  PunchOSFlatButton({this.onPressed, this.label, this.bold = false});

  final bool bold;
  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return FlatButton(child: Text(label, style: bold ? AppTextStyles.eventDetailsOrangeBold : AppTextStyles.eventLinks), onPressed: onPressed);
  }
}

class LabelText extends StatelessWidget {
  LabelText({this.label, this.value});

  final String label;
  final String value;

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: <Widget>[
        Padding(
          padding: EdgeInsets.fromLTRB(18, 13, 0, 6),
          child: Text(
            label,
            style: AppTextStyles.styleWhiteBold(15),
          ),
        ),
        Padding(
          padding: EdgeInsets.fromLTRB(18, 6, 0, 13),
          child: Text(
            value,
            style: AppTextStyles.styleWhite(16),
          ),
        ),
      ],
    );
  }
}

class StyledTextFormField extends StatelessWidget {
  StyledTextFormField({
    this.field,
    this.editingController,
    this.value,
    this.action,
    this.label,
    this.maxLines,
    this.autoval,
    this.numbersOnly = false,
    this.myFocusNode,
  });

  final FocusNode myFocusNode;
  final void Function(String, String) action;
  final String field;
  final String label;
  final bool numbersOnly;
  final List<String> autoval;
  final int maxLines;
  final String value;

  final TextEditingController editingController;

  void onSavedAction(String s) {
    action(field, s);
  }

  @override
  Widget build(BuildContext context) {
    if (editingController != null) editingController.text = value;
    return Padding(
      padding: EdgeInsets.symmetric(vertical: 12.0, horizontal: 16.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          Text(label, style: AppTextStyles.styleWhiteBold(15)),
          SizedBox(height: 10),
          TextFormField(
            autovalidate: autoval != null,
            keyboardType: numbersOnly ? TextInputType.phone : TextInputType.text,
            maxLines: maxLines == null ? 1 : maxLines,
            controller: editingController,
            style: AppTextStyles.textForm,
            focusNode: myFocusNode != null ? myFocusNode : null,
            decoration: InputDecoration(
              contentPadding: EdgeInsets.all(16.0),
              hintText: label,
              hintStyle: AppTextStyles.labelRegularLight,
              filled: true,
              fillColor: AppColors.appColorWhite,
              enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: AppColors.appColorAccent, width: 1)),
              border: OutlineInputBorder(borderSide: BorderSide(color: AppColors.appColorAccent, width: 1)),
              focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: AppColors.appColorAccent, width: 2)),
            ),
            onSaved: onSavedAction,
            validator: (String value) {
              int matches = 0;
              if (value != " " && value != null && value != "") {
                autoval.forEach((String s) {
                  if (s.contains(value)) matches++;
                });
              } else {
                return null;
              }
              return matches > 0 ? matches.toString() : 'Invalid value';
            },
          )
        ],
      ),
    );
  }
}

class StyledTextFormFieldField extends StatelessWidget {
  StyledTextFormFieldField({
    this.editingController,
    this.value,
    this.action,
    this.label,
    this.maxLines,
    this.autoval,
    this.numbersOnly = false,
    this.myFocusNode,
  });

  final FocusNode myFocusNode;
  final void Function(String) action;
  final String label;
  final bool numbersOnly;
  final List<String> autoval;
  final int maxLines;
  final String value;

  final TextEditingController editingController;

  @override
  Widget build(BuildContext context) {
    if (editingController != null) editingController.text = value;
    return TextFormField(
      autovalidate: autoval != null,
      keyboardType: numbersOnly ? TextInputType.phone : TextInputType.text,
      maxLines: maxLines == null ? 1 : maxLines,
      controller: editingController,
      style: AppTextStyles.textForm,
      focusNode: myFocusNode != null ? myFocusNode : null,
      decoration: InputDecoration(
        contentPadding: EdgeInsets.all(16.0),
        hintText: label,
        hintStyle: AppTextStyles.labelRegularLight,
        filled: true,
        fillColor: AppColors.appColorWhite,
        enabledBorder: OutlineInputBorder(borderSide: BorderSide(color: AppColors.appColorAccent, width: 1)),
        border: OutlineInputBorder(borderSide: BorderSide(color: AppColors.appColorAccent, width: 1)),
        focusedBorder: OutlineInputBorder(borderSide: BorderSide(color: AppColors.appColorAccent, width: 2)),
      ),
      onSaved: action,
      validator: (String value) {
        int matches = 0;
        if (value != " " && value != null && value != "") {
          autoval.forEach((String s) {
            if (s.contains(value)) matches++;
          });
        } else {
          return null;
        }
        return matches > 0 ? matches.toString() : 'Invalid value';
      },
    );
  }
}

class TabBarPadding extends StatelessWidget {
  TabBarPadding({this.iconD, this.label});

  final Icon iconD;
  final String label;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Padding(
      padding: EdgeInsets.symmetric(horizontal: 12, vertical: 0),
      child: Row(
        children: <Widget>[
          IconButton(
            icon: iconD,
            onPressed: () {},
          ),
          Text(label),
        ],
      ),
    );
  }
}

class LabelListTile extends StatelessWidget {
  LabelListTile({this.label, this.trailing});

  final String label;
  final Widget trailing;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(14),
      color: AppColors.appAccentYellow,
      child: Text(
        label,
        textAlign: TextAlign.center,
        style: AppTextStyles.bannerTitle,
      ),
    );
  }
}

class PunchEventNav extends StatelessWidget {
  PunchEventNav({this.selectedIndex, this.onItemTapped});

  final Function(int) onItemTapped;
  final int selectedIndex;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return BottomNavigationBar(items: <BottomNavigationBarItem>[
      BottomNavigationBarItem(icon: Icon(Icons.home), title: Text('Home')),
      BottomNavigationBarItem(icon: Icon(Icons.event_available), title: Text('Attending')),
      BottomNavigationBarItem(icon: Icon(Icons.offline_pin), title: Text('Offline')),
    ], currentIndex: selectedIndex, fixedColor: Colors.deepPurple, onTap: onItemTapped);
  }
}

class UIUtils {
  static List<DropdownMenuItem<String>> createDropdownItems(List<String> choices) {
    return choices.map((String value) {
      return DropdownMenuItem<String>(
        value: value,
        child: Text(value),
      );
    }).toList();
  }

//TODO create notifications
//  static List<PopupMenuItem<String>> createNotificationsItems(ListNotification notifs) {
//    List<PopupMenuItem<String>> popupList = <PopupMenuItem<String>>[];
//    notifs.notificationList.forEach((ItemNotification inot) {
//      popupList.add(PopupMenuItem<String>(
//        value: inot.key,
//        child: Text(inot.message, style: AppTextStyles.labelRegularLight),
//      ));
//    });
//    return popupList;
//  }
}

//class StyledTextFormField extends StatelessWidget {
//  StyledTextFormField({this.field, this.editingController, this.value, this.action, this.label, this.maxLines, this.numbersOnly = false});
//
//  final void Function(String, String) action;
//  final String field;
//  final String label;
//  final bool numbersOnly;
//  final int maxLines;
//  final String value;
//
//  final TextEditingController editingController;
//
//  void onSavedAction(String s) {
//    action(field, s);
//  }
//
//  @override
//  Widget build(BuildContext context) {
//    editingController.text = value;
//    return Padding(
//      padding: EdgeInsets.symmetric(vertical: 4.0, horizontal: 8.0),
//      child: TextFormField(
//        keyboardType: numbersOnly ? TextInputType.phone : TextInputType.text,
//        maxLines: maxLines == null ? 1 : maxLines,
//        controller: editingController,
//        decoration: InputDecoration(
//          contentPadding: EdgeInsets.all(12.0),
//          hintText: label,
//          border: OutlineInputBorder(),
//        ),
//        onSaved: onSavedAction,
//      ),
//    );
//  }
//}

class AppColors {
  static Color appColorMain = Color.fromARGB(255, 21, 26, 83);
  static Color appColorMainTransparent = Color.fromARGB(178, 21, 26, 83);
  static Color appColorBackground = Color.fromARGB(255, 20, 25, 82);
  static Color appColorSecondary = Color.fromARGB(255, 51, 161, 253);
  static Color appAccentYellow = Color.fromARGB(255, 253, 218, 73);
  static Color appAccentPurple = Color.fromARGB(255, 140, 82, 255);
  static Color appAccentOrange = Color.fromARGB(255, 248, 147, 31);
  static Color appBlue = Color.fromARGB(255, 4, 150, 255);
  static Color appGreyBlue = Color.fromARGB(255, 116, 122, 155);

  static Color appGreyscalePlus = Color.fromARGB(255, 175, 175, 175);
  static Color appGreyscaleBaseline = Color.fromARGB(255, 152, 152, 152);
  static Color appGreyscaleMinus = Color.fromARGB(255, 93, 93, 93);
  static Color appGreyscaleMinus2 = Color.fromARGB(255, 60, 60, 60);
  static Color appGreyscaleMinus3 = Color.fromARGB(255, 54, 53, 55);

  static Color appColorAccent = Color.fromARGB(255, 140, 82, 255);
  static Color appColorLightMinus = Color.fromARGB(255, 119, 119, 119);
  static Color appColorDark = Color.fromARGB(255, 70, 70, 70);
  static Color appColorLight = Color.fromARGB(255, 154, 154, 154);
  static Color appColorLightPlus = Color.fromARGB(255, 172, 172, 172);
  static Color appColorRed = Color.fromARGB(255, 208, 0, 0);
  static Color appColorWhite = Colors.white;
  static Color appColorThinkBlue = Color.fromARGB(255, 59, 138, 233);
  static Color appColorBlue = Color.fromARGB(255, 59, 138, 233);
  static Color appColorBlueAccent = Color.fromARGB(255, 33, 194, 210);
}

class AppTextStyles {
  static TextStyle titleBig = TextStyle(
    fontSize: 22.0,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorBlue,
  );
  static TextStyle titleLarge = TextStyle(
    fontSize: 18.0,
    color: AppColors.appColorLight,
  );
  static TextStyle titleStyle = TextStyle(
    fontSize: 16.0,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorLight,
  );
  static TextStyle titleStyleDark = TextStyle(
    fontSize: 16.0,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorDark,
  );
  static TextStyle titleStyleLight = TextStyle(
    fontSize: 16.0,
    color: AppColors.appColorLight,
  );
  static TextStyle titleStyleBlue = TextStyle(
    fontSize: 16.0,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorBlue,
  );
  static TextStyle priceRegular = TextStyle(
    fontWeight: FontWeight.bold,
    fontSize: 16.0,
    color: AppColors.appColorRed,
  );
  static TextStyle priceMini = TextStyle(
    fontWeight: FontWeight.bold,
    fontSize: 12.0,
    color: AppColors.appColorRed,
  );
  static TextStyle priceMiniLight = TextStyle(
    fontSize: 12.0,
    color: AppColors.appColorRed,
  );
  static TextStyle labelMiniBold = TextStyle(
    fontWeight: FontWeight.bold,
    fontSize: 12.0,
    color: AppColors.appColorLightMinus,
  );
  static TextStyle labelMiniDarkBold = TextStyle(
    fontWeight: FontWeight.bold,
    fontSize: 12.0,
    color: AppColors.appColorLight,
  );
  static TextStyle labelMini = TextStyle(
    fontSize: 12.0,
    color: AppColors.appColorLightPlus,
  );
  static TextStyle labelMiniBlue = TextStyle(
    fontSize: 12.0,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorThinkBlue,
  );
  static TextStyle labelMiniDark = TextStyle(
    fontSize: 12.0,
    color: AppColors.appColorLightMinus,
  );
  static TextStyle labelDark = TextStyle(
    fontSize: 16.0,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorLightMinus,
  );
  static TextStyle labelRegular = TextStyle(
    fontSize: 14.0,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorLight,
  );
  static TextStyle labelRegularLight = TextStyle(
    fontSize: 14.0,
    color: AppColors.appColorLight,
  );
  static TextStyle labelWhite = TextStyle(
    fontSize: 18.0,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorWhite,
  );
  static TextStyle labelWhiteMini = TextStyle(
    fontSize: 12.0,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorWhite,
  );
  static TextStyle styleWhiteBold16 = TextStyle(
    fontSize: 16,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorWhite,
  );

  static TextStyle appbarTitle = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 16,
    color: AppColors.appColorWhite,
  );
  static TextStyle textForm = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 14,
    color: AppColors.appGreyscaleMinus3,
  );
  static TextStyle dialogDescription = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 16,
    color: AppColors.appGreyscaleMinus3,
  );
  static TextStyle eventTitle = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 18,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorMain,
  );
  static TextStyle eventDetails = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 14,
    color: AppColors.appColorMain,
  );
  static TextStyle eventDetailsBold = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 12,
    fontWeight: FontWeight.bold,
    color: AppColors.appGreyscaleBaseline,
  );
  static TextStyle eventLinks = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 14,
    decoration: TextDecoration.underline,
    color: AppColors.appAccentOrange,
  );
  static TextStyle eventDetailsOrangeBold = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 14,
    fontWeight: FontWeight.bold,
    color: AppColors.appAccentOrange,
  );
  static TextStyle eventDetailsGrey = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 14,
    color: AppColors.appGreyscaleMinus,
  );
  static TextStyle bannerTitle = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 14,
    fontWeight: FontWeight.bold,
    color: AppColors.appColorMain,
  );
  static TextStyle bannerDateDay = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 30,
    fontWeight: FontWeight.bold,
    color: AppColors.appGreyscaleMinus2,
  );
  static TextStyle bannerDateMonth = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 14,
    fontWeight: FontWeight.bold,
    color: AppColors.appGreyscaleMinus2,
  );
  static TextStyle bannerDate = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 12,
    color: AppColors.appGreyscaleBaseline,
  );
  static TextStyle bannerDescription = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 12,
    color: AppColors.appGreyscaleMinus,
  );
  static TextStyle bannerActions = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 12,
    color: AppColors.appGreyBlue,
  );
  static TextStyle bannerActionsClicked = TextStyle(
    fontFamily: 'FSElliotPro',
    fontSize: 12,
    fontWeight: FontWeight.bold,
    color: AppColors.appGreyBlue,
  );

  static TextStyle styleWhite(double s) {
    return TextStyle(
      fontFamily: 'FSElliotPro',
      fontSize: s,
      color: AppColors.appColorWhite,
    );
  }

  static TextStyle styleWhiteBold(double s) {
    return TextStyle(
      fontFamily: 'FSElliotPro',
      fontSize: s,
      fontWeight: FontWeight.bold,
      color: AppColors.appColorWhite,
    );
  }

  static TextStyle styleBlueBold(double s) {
    return TextStyle(
      fontFamily: 'FSElliotPro',
      fontSize: s,
      fontWeight: FontWeight.bold,
      color: AppColors.appBlue,
    );
  }
}
