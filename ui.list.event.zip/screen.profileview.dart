import 'package:flutter/material.dart';
import 'model.profile.dart';
import 'ui.backdrop.dart';
import 'ui.util.dart';
import 'util.dialog.dart';

//class ScreenProfile extends StatelessWidget {
//  ScreenProfile({this.profile});
//
//  final Profile profile;
//
//  @override
//  Widget build(BuildContext context) {
//    return ScreenProfileState(profile: profile);
//  }
//}
//
//class ScreenProfileState extends StatefulWidget {
//  ScreenProfileState({this.profile});
//
//  final Profile profile;
//
//  @override
//  _ScreenProfileBuild createState() => new _ScreenProfileBuild(profile: profile);
//}

//class _ScreenProfileBuild extends State<ScreenProfileState> with SingleTickerProviderStateMixin {
//  _ScreenProfileBuild({this.profile});
//
//  final Profile profile;
//  GenericDialogGenerator dialog;
//  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
//
//  TabController tabController;
//
//  @override
//  void initState() {
//    tabController = new TabController(length: 3, vsync: this);
//    dialog = GenericDialogGenerator.init(context);
//    super.initState();
//  }
//
////  List<DropdownMenuItem<String>> employeeTypeItems = <DropdownMenuItem<String>>[];
//
//  void saveValue(String key, String value) {}
//
//
//  @override
//  Widget build(BuildContext context) {
//    final FormState form = _formKey.currentState;
//    return new Theme(
//      data: new ThemeData(
//        brightness: Brightness.light,
//        platform: Theme.of(context).platform,
//      ),
//      child: new Stack(
//        children: <Widget>[
//          Backdrop(),
//          Scaffold(
//            appBar: AppBar(
//              bottom: TabBar(
//                controller: tabController,
//                isScrollable: true,
//                tabs: <Widget>[
//                  TabBarPadding(iconD: Icon(Icons.event_note), label: 'All events'),
//                  TabBarPadding(iconD: Icon(Icons.event_available), label: 'My events'),
//                  TabBarPadding(iconD: Icon(Icons.person), label: 'My profile'),
//                ],
//              ),
//              backgroundColor: AppColors.appColorMainTransparent,
//              automaticallyImplyLeading: false,
//              title: Image.asset(
//                'images/logo_punch-main.png',
//                height: 40,
//              ),
//              actions: AppBarWidgets.actions,
//            ),
//            backgroundColor: const Color(0x00000000),
//            body: Form(
//              key: _formKey,
//              child: SingleChildScrollView(
//                child: Column(
//                  crossAxisAlignment: CrossAxisAlignment.start,
//                  children: <Widget>[
//                    Padding(
//                      padding: EdgeInsets.all(20),
//                      child: Text('My profile', style: AppTextStyles.styleWhiteBold(22)),
//                    ),
//                    ProfileAvatar(profile),
//                    StyledTextFormField(editingController: firstNameController, field: "First", action: saveValue, label: "First name"),
//                    StyledTextFormField(editingController: lastNameController, field: "Last", action: saveValue, label: "Last name"),
//                    StyledTextFormField(editingController: idNumberController, field: "ID", action: saveValue, label: "ID number"),
//                    SizedBox(height: 36),
//                    StyledTextFormField(editingController: groupController, field: "Group", autoval: groups, action: saveValue, label: "Group"),
//                    StyledTextFormField(editingController: divisionController, field: "Division", action: saveValue, label: "Division"),
//                    StyledTextFormField(editingController: deptController, field: "Department", action: saveValue, label: "Department"),
//                    SizedBox(height: 36),
//                    PunchRaisedButton(action: () => form.save, label: "Save"),
//                    SizedBox(height: 36),
//                  ],
//                ),
//              ),
//            ),
//          )
//        ],
//      ),
//    );
//  }
//}

class ViewProfile extends StatelessWidget {
  ViewProfile({this.profile, this.onPressed});

  final Profile profile;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (BuildContext context, int index) {
          switch (index) {
            case 0:
              return Container(
                padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
                child: Text('My profile', style: AppTextStyles.styleWhiteBold(22)),
              );
            case 1:
              return ProfileAvatar(profile);
              break;
            case 2:
              return Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: <Widget>[
                  LabelText(label: 'ID no.', value: profile.idNumber),
                  LabelText(label: 'Group', value: profile.group),
                  LabelText(label: 'Division', value: profile.division),
                  LabelText(label: 'Department', value: profile.department),
                ],
              );
              break;
            case 3:
              return Row(
                children: <Widget>[
                  PunchOSFlatButton(label: 'Edit my information', onPressed: onPressed, bold: true),
//                  FlatButton(child: Text('Edit my information', style: AppTextStyles.styleBlueBold(16)), onPressed: onPressed),
                ],
              );
              break;
          }
        },
        childCount: 4,
      ),
    );
  }
}

class ProfileAvatar extends StatelessWidget {
  ProfileAvatar(this.profile);

  final Profile profile;

  @override
  Widget build(BuildContext context) {
    // TODO: implement build
    return Container(
        height: 132,
        width: double.infinity,
        child: Stack(
          children: <Widget>[
            Positioned(
                left: 16,
                top: 16,
                child: ClipOval(
                    child: Hero(
                  tag: "Avatar",
                  child: profile.photo == null ? Icon(Icons.person) : Image.network(profile.photo),
                ))),
            Positioned.fill(
                left: 132,
                right: 16,
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  mainAxisSize: MainAxisSize.max,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(profile.name, style: AppTextStyles.styleWhiteBold(16)),
                    SizedBox(height: 5),
                    Text(profile.email, style: AppTextStyles.styleWhiteBold(14)),
                  ],
                )),
          ],
        ));
  }
}

class ProfileForm extends StatefulWidget {
  ProfileForm({this.profile, this.onFinished, this.onError});

  final Profile profile;
  final VoidCallback onError;
  final Function(Map<String, String>) onFinished;

  @override
  _ProfileFormBuild createState() => new _ProfileFormBuild(profile: profile, onFinished: onFinished, onError: onError);
}

class _ProfileFormBuild extends State<ProfileForm> {
  final GlobalKey<FormState> _formKey = new GlobalKey<FormState>();

  _ProfileFormBuild({this.profile, this.onFinished, this.onError});

  final Profile profile;
  final VoidCallback onError;
  bool enabled = true;
  final Function(Map<String, String>) onFinished;
  Map<String, String> updatedProfile;
  final TextEditingController firstNameController = TextEditingController();
  final TextEditingController lastNameController = TextEditingController();
  final TextEditingController groupController = TextEditingController();
  final TextEditingController divisionController = TextEditingController();
  final TextEditingController deptController = TextEditingController();
  final TextEditingController idNumberController = TextEditingController();
  FocusNode myFocusNode;
  bool groupInFocus = false;
  bool built = false;

  void saveDetails() {
    final FormState form = _formKey.currentState;
    updatedProfile = {};
    form.save();
    updatedProfile.length == 6 ? onFinished(updatedProfile) : onError();
    setState(() {
      enabled = updatedProfile.length == 6 ? false : true;
    });
  }

  @override
  void initState() {
    super.initState();
    firstNameController.text = profile.firstName;
    lastNameController.text = profile.lastName;
    groupController.text = profile.group;
    divisionController.text = profile.division;
    deptController.text = profile.department;
    idNumberController.text = profile.idNumber;
    myFocusNode = FocusNode();
    myFocusNode.addListener(inFocus);
  }

  void setGroup(String s) {
    Navigator.pop(context);
    setState(() {
      built = false;
    });
    groupController.text = s;
    myFocusNode.addListener(inFocus);
  }

  void inFocus() {
    myFocusNode.unfocus();
    if (!built)
      showModalBottomSheet(
          context: context,
          builder: (BuildContext context) {
            return GroupList(
              onDelete: setGroup,
            );
          });
    setState(() {
      built = true;
    });
  }

  @override
  void dispose() {
    myFocusNode.dispose();
    super.dispose();
  }

  void saveValue(String key, String value) {
    if (value != "" && value != " " && !RegExp(r'[^0-9A-Za-z,.\/-\s]').hasMatch(value)) updatedProfile[key] = value;
  }

  @override
  Widget build(BuildContext context) {
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (BuildContext context, int index) {
          return new Form(
            key: _formKey,
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                StyledTextFormField(editingController: firstNameController, field: "First", action: saveValue, label: "First name"),
                StyledTextFormField(editingController: lastNameController, field: "Last", action: saveValue, label: "Last name"),
                SizedBox(height: 36),
                StyledTextFormField(editingController: idNumberController, field: "ID", action: saveValue, label: "ID number"),
                StyledTextFormField(editingController: groupController, field: "Group", myFocusNode: myFocusNode, action: saveValue, label: "Group"),
                StyledTextFormField(editingController: divisionController, field: "Division", action: saveValue, label: "Division"),
                StyledTextFormField(editingController: deptController, field: "Department", action: saveValue, label: "Department"),
                SizedBox(height: 36),
                PunchRaisedButton(action: () => saveDetails(), label: "Save"),
                SizedBox(height: 36),
              ],
            ),
          );
        },
        childCount: 1,
      ),
    );
  }
}

class GroupList extends StatelessWidget {
  GroupList({this.onDelete});

  final Function(String) onDelete;

  List<String> groups = <String>[
    'Broadband Business',
    'Channel Management',
    'Corportate and Legal Services',
    'Creative Marketing and Multimedia Business',
    'Enterprise',
    'Finance and Administration',
    'Human Resources',
    'Information Systems',
    'Mobile Business',
    'Network Technical',
    'New Business',
    'Office of the CTIO',
    'OSMCE',
    'Office of the CCO',
    'Office of the President',
    'Pipeline Management',
    'Small and Medium Business',
    'Others'
  ];

  @override
  Widget build(BuildContext context) {
    return ListView(
      children: groups.map<Widget>((String s) {
        return FlatButton(
          child: Text(s, style: AppTextStyles.textForm),
          onPressed: () => onDelete(s),
        );
      }).toList(),
    );
  }
}
