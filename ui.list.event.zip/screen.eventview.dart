import 'package:flutter/material.dart';
import 'model.events.dart';
import 'model.attendance.dart';
import 'ui.backdrop.dart';
import 'ui.eventWidgets.dart';
import 'ui.util.dart';
import 'ui.eventActions.dart';
import 'util.qr.dart';
import 'util.dialog.dart';
import 'model.feedback.dart';
import 'screen.feedback.dart';
import 'screen.questions.dart';
import 'model.profile.dart';
import 'screen.textDialog.dart';

class ScreenEventView extends StatelessWidget {
  ScreenEventView({this.loadEvent, this.profile});

  final Event loadEvent;
  final Profile profile;

  @override
  Widget build(BuildContext context) {
    return new ScreenEventViewState(
      loadEvent: loadEvent,
      profile: profile,
    );
  }
}

class ScreenEventViewState extends StatefulWidget {
  ScreenEventViewState({this.loadEvent, this.profile});

  final Event loadEvent;
  final Profile profile;

  @override
  _ScreenEventViewBuild createState() => new _ScreenEventViewBuild(loadEvent: loadEvent, profile: profile);
}

class _ScreenEventViewBuild extends State<ScreenEventViewState> {
  _ScreenEventViewBuild({this.loadEvent, this.profile});

  GenericDialogGenerator dialog;
  Profile profile;
  Event loadEvent;
  Attendees eventAttendees;
  Attendance myAttendance;
  FeedbackQuestions eventFeedback;
  bool isCollaborator = false;
  bool isCreator = true;
  bool editing = false;
  List<String> collaborators = <String>[];
  List<EventLink> eventLinks = <EventLink>[];

  @override
  void initState() {
    loadEvent.getCollaborators(setCollaborators);
    loadEvent.getLinks(setLinks);
    dialog = GenericDialogGenerator.init(context);
    eventAttendees = Attendees.createByEventID(loadEvent.eventKey);
    eventAttendees.getFirebase(() {
      setState(() {
        if (profile.userKey != null && eventAttendees.eventAttendees.containsKey(profile.userKey)) {
          myAttendance = eventAttendees.eventAttendees[profile.userKey];
        } else {
          myAttendance = Attendance.newAttendance(profile.userKey);
        }
        myAttendance.setName(profile.name);
        myAttendance.setEventID(loadEvent.eventKey);
      });
    });
    super.initState();
  }

  void setLinks(List<EventLink> links) {
    setState(() {
      eventLinks = links;
    });
  }

  void setCollaborators(List<String> collabs) {
    setState(() {
      collaborators = collabs;
    });
  }

  void actionPressed(String s) {
    switch (s) {
      case "feedback":
        sendFeedback();
        break;
      case "qorf":
        break;
      case "question":
        showQA();
        break;
      case "checkin":
        checkIn();
        break;
      case "register":
        register();
        break;
      case "admin":
        showAdminActions();
        break;
      case "doneEditing":
        saveEdits();
        break;
      case "edit":
        setState(() {
          editing = true;
        });
        break;
      case "noFB":
        dialog.confirmDialog(dialog.feedbackAlreadySubmittedString);
        break;
      case "collab":
        showCollab();
        break;
      case "notif":
        sendNotificationToAttendees();
        break;
      case "scan":
        scanAttendee();
        break;
    }
  }

  void showQA() {
    Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ScreenQuestions(
                  userid: profile.userKey,
                  eventAttendees: eventAttendees,
                  myAttendance: myAttendance,
                )));
  }

  void showAdminActions() {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return AdminButtons(
            myAttendance: myAttendance,
            isCreator: isCreator,
            onPress: (String action) {
              Navigator.pop(context);
              actionPressed(action);
            },
          );
        });
  }

  void showCollab() {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return CollabList(
            collabs: collaborators,
            onAdd: addCollab,
            onDelete: removeCollab,
          );
        });
  }

  void refreshCollab(bool add, List<String> collabs) {
    setCollaborators(collabs);
    dialog.confirmDialog(add ? dialog.collabAddedString : dialog.collabRemovedString, onYes: showCollab);
  }

  void removeCollab(String s) {
    Navigator.pop(context);
    dialog.choiceDialog(dialog.collabAskRemoveString, onYes: () => loadEvent.removeCollaborator(s, (List<String> cc) => refreshCollab(false, cc)));
  }

  void addCollab() {
    Navigator.pop(context);
    ScreenTextInit.doThis(context, dialog.collabScreen(loadEvent.eventDetails.name), (String s) {
      loadEvent.addCollaborator(s, (List<String> cc) => refreshCollab(true, cc));
    });
  }

  void cancelEvent() async {
    ScreenTextInit.doThis(context, dialog.cancelString(loadEvent.eventDetails.name),
        (String s) => myAttendance.setAttendanceCancel(s, () => dialog.confirmDialog(dialog.attendanceCancelConfirmString)));
  }

  void askQuestion() {
    ScreenTextInit.doThis(context, dialog.askQuestionString(loadEvent.eventDetails.name),
        (String s) => myAttendance.askQuestion(s, () => dialog.confirmDialog(dialog.questionSubmittedString)));
  }

  void sendNotificationToAttendees() {
    ScreenTextInit.doThis(context, dialog.broadcastString(loadEvent.eventDetails.name),
        (String s) => loadEvent.sendNotif(s, () => dialog.confirmDialog(dialog.notifSubmittedString)));
  }

  void sendFeedback() async {
    List<Response> responseList = await Navigator.push(
        context,
        MaterialPageRoute(
            builder: (context) => ScreenFeedback(
                  editable: isCreator,
                  eventKey: loadEvent.eventKey,
                  eventName: loadEvent.eventDetails.name,
                )));
    if (responseList != null) myAttendance.sendFeedback(responseList, () => dialog.confirmDialog(dialog.feedbackSubmittedString));
  }

  void scanAttendee() {
    QRActions.scanCheckInAttendee(
        eventID: loadEvent.eventKey,
        returnCode: (String s) => eventAttendees.checkIn(s, checkInResult),
        wrongQR: () => dialog.confirmDialog(dialog.wrongQRString));
  }

  void checkInResult(bool s) {
    if (s) dialog.confirmDialog(dialog.checkedInAttendeeString);
  }

  void checkIn() {
    showModalBottomSheet(
        context: context,
        builder: (BuildContext context) {
          return CheckInWidget(
            qrWidget: QRGenerator.attendeeEventQR(eventID: loadEvent.eventKey, userKey: profile.userKey),
            scanQR: () {
              Navigator.pop(context);
              QRActions.scanCheckInSelf(eventID: loadEvent.eventKey, returnCode: (String s) {}, wrongQR: () {});
            },
//            cancel: () {
//              Navigator.pop(context);
//              cancelEvent();
//            },
          );
        });
  }

  void saveEdits() {
    setState(() {
      editing = false;
    });
  }

  void attendanceRefreshed() {
    setState(() {});
  }

  void register() {
    myAttendance.setAttendance(() {
      dialog.confirmDialog(dialog.registeredString(loadEvent.eventDetails.name));
      attendanceRefreshed();
    });
  }

  @override
  Widget build(BuildContext context) {
    if (myAttendance != null) myAttendance.setTime(loadEvent.end, loadEvent.canAskQuestions);
    return new Theme(
      data: new ThemeData(
        brightness: Brightness.light,
        platform: Theme.of(context).platform,
      ),
      child: new Stack(
        children: <Widget>[
          Backdrop(),
          Scaffold(
            appBar: AppBar(
              leading: IconButton(icon: Icon(Icons.keyboard_arrow_left), onPressed: () => Navigator.pop(context)),
              backgroundColor: AppColors.appColorBackground,
              title: Text(loadEvent.eventDetails.name, style: AppTextStyles.appbarTitle),
            ),
            backgroundColor: AppColors.appColorWhite,
            floatingActionButtonLocation: FloatingActionButtonLocation.centerFloat,
            floatingActionButton: EventActions(
              myAttendance: myAttendance,
              editing: editing,
              isCollaborator: collaborators.contains(profile.email),
              actionPressed: actionPressed,
            ),
            body: CustomScrollView(
              slivers: <Widget>[
                SliverAppBar(
                  flexibleSpace: StaticBanner(loadEvent: loadEvent),
                  expandedHeight: 200,
                  automaticallyImplyLeading: false,
                ),
                SliverList(
                  delegate: SliverChildBuilderDelegate(
                    (BuildContext context, int index) {
                      switch (index) {
                        case 0:
                          return EventStatus(myAttendance: myAttendance);
                        case 1:
                          return Padding(
                            padding: EdgeInsets.all(18),
                            child: Text(
                              loadEvent.eventDetails.name,
                              style: AppTextStyles.eventTitle,
                            ),
                          );
                        case 2:
                          return EventDetailsBar(loadEvent: loadEvent);
                        case 3:
                          return SessionDetailsBar();
                        case 4:
                          return AttendeesDetailsBar(loadEvent: loadEvent, eventAttendees: eventAttendees.eventAttendees.length);
                        case 5:
                          return Padding(
                            padding: EdgeInsets.all(18),
//                            child: Text(
//                                'Lorem ipsum dolor sit amet, sed hinc adipiscing in, eam id pertinacia persequeris. Et mel labitur bonorum concludaturque, veri harum est ea. Probatus repudiare assueverit his ei, pri viris meliore ne. Idque percipitur ut cum, pri ut tation voluptatibus.\nDolor facilisis mel cu, at voluptua insolens dissentiet mel. Cu doming virtute propriae sea, te numquam adipisci usu, ea his option posidonium. Populo noluisse menandri ei eum. Liber blandit detraxit sed id, at per nibh fuisset. In viderer appareat postulant per, eos te tale adhuc voluptua. Ne has nibh aperiam comprehensam, pri ei euripidis signiferumque.\nOratio putent est eu, et usu malis ridens, falli complectitur contentiones an eos. Ius id tempor similique consetetur. Eu vix mentitum mediocrem scribentur, sea ei unum erant. Velit impedit sapientem ad cum, ex quando constituto nec. Accumsan consetetur mediocritatem vim in, in veritus fabellas detraxit est.\nUllum sanctus salutatus mei et, ne nec malorum voluptaria. Nec stet dicat ne, qui graeci quodsi saperet no. Duis nominati no eam, mea graeco putant ei. At alia semper vis, usu an fabulas menandri. Ea dolor postea nam, liber choro sententiae no eos. Te mel ridens adipisci persequeris. Ad nihil graece iuvaret vim.\nEos no ludus constituto. Ei saepe ancillae cotidieque eam, vel probo quando ei. Eu illud quodsi cetero vis. Duo errem libris no, ne sint pertinax referrentur nam.',
//                                style: AppTextStyles.eventDetailsGrey),
                            child: Text(loadEvent.eventDetails.longDescription, style: AppTextStyles.eventDetailsGrey),
                          );
                        case 6:
                          return RelatedInfoDetailsBar(eventLinks: eventLinks);
                        case 7:
                          return Padding(
                            padding: EdgeInsets.all(18),
                            child: EventIcons(space: false, interestedval: loadEvent.isInterested),
                          );
//                        case 8:
//                          return Text('Badges/Booths');
                        case 8:
                          return SizedBox(height: 100);
                      }
                    },
                    childCount: 9,
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
