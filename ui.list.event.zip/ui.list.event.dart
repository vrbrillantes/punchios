import 'package:flutter/material.dart';
import 'model.events.dart';
import 'ui.eventWidgets.dart';
import 'ui.util.dart';

class ListEvent extends StatelessWidget {
  ListEvent({this.title = "List", this.onPressed, this.allEvents, this.showEvents, this.onLongPress, this.interestedList});

  final Function(String) onPressed;
  final String title;
  final Map<String, Event> allEvents;
  final List<String> showEvents;
  final List<String> interestedList;

  final Function(String) onLongPress;

  @override
  Widget build(BuildContext context) {
    List<Event> sortedEvents = <Event>[];
    showEvents.forEach((String key) {
      if (allEvents.containsKey(key)) {
        sortedEvents.add(allEvents[key]);
      }
    });
    sortedEvents.sort((a, b) => a.start.datetime.compareTo(b.start.datetime));
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (BuildContext context, int index) {
          if (index == 0) {
            return sortedEvents.length == 0
                ? SizedBox()
                : Container(
                    padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
                    child: Text(title, style: AppTextStyles.styleWhiteBold(22)),
                  );
          } else {
            return EventBanner(
              loadEvent: sortedEvents[index - 1],
              onPressed: () => onPressed(sortedEvents[index - 1].eventKey),
              onLongPress: () => onLongPress(sortedEvents[index - 1].eventKey),
              isInterested: interestedList.contains(sortedEvents[index - 1].eventKey),
            );
          }
        },
        childCount: sortedEvents.length + 1,
      ),
    );
  }
}

class HorizontalListEvent extends StatelessWidget {
  HorizontalListEvent({this.title = "List", this.onPressed, this.allEvents, this.showEvents, this.onLongPress, this.interestedList});

  final Function(String) onPressed;
  final String title;
  final Map<String, Event> allEvents;
  final List<String> showEvents;
  final List<String> interestedList;

  final Function(String) onLongPress;

  @override
  Widget build(BuildContext context) {
    List<Event> sortedEvents = <Event>[];
    showEvents.forEach((String key) {
      if (allEvents.containsKey(key)) {
        if (allEvents[key].end.datetime.isAfter(DateTime.now().subtract(Duration(days: 3)))) sortedEvents.add(allEvents[key]);
      }
    });
    sortedEvents.sort((a, b) => a.start.datetime.compareTo(b.start.datetime));
//    sortedEvents = sortedEvents.sublist(0, 1);
    List<Widget> viewEvent = sortedEvents.map<Widget>((Event e) {
      return Container(
        width: 300.0,
        child: VerticalBanner(
          loadEvent: e,
          onPressed: () => onPressed(e.eventKey),
          onShowInterest: () => onLongPress(e.eventKey),
          isInterested: interestedList.contains(e.eventKey),
        ),
      );
    }).toList();
    if (sortedEvents.length > 3) {
      viewEvent.add(Container(
        width: 110.0,
        child: VerticalEventsButton(onPressed: () {}),
      ));
    }
//    sortedEvents.forEach((Event e) {
//      if (!e.end.datetime.isAfter(DateTime.now().subtract(Duration(days: 3)))) sortedEvents.remove(e);
//      DateTime.now().isBefore(e.end.datetime.add(Duration(days: 3))) sortedEvents.remove(e);
//    });
    return SliverList(
      delegate: SliverChildBuilderDelegate(
        (BuildContext context, int index) {
          if (index == 0) {
            return sortedEvents.length == 0
                ? SizedBox()
                : Container(
                    padding: EdgeInsets.symmetric(vertical: 20.0, horizontal: 20.0),
                    child: Text(title, style: AppTextStyles.styleWhiteBold(22)),
                  );
          } else {
            return sortedEvents.length == 0
                ? SizedBox()
                : Container(
                    height: 270,
                    child: ListView(padding: EdgeInsets.symmetric(horizontal: 18), scrollDirection: Axis.horizontal, children: viewEvent),
                  );
          }
        },
        childCount: 2,
      ),
    );
  }
}
