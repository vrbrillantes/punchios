import 'package:firebase_database/firebase_database.dart';
import 'dart:async';

//final dbEvents = FirebaseDatabase.instance.reference().child('Events');
final dbEventList = FirebaseDatabase.instance.reference().child('EventList');
final dbEventFeedback = FirebaseDatabase.instance.reference().child('EventFeedback');
final dbEventLinks = FirebaseDatabase.instance.reference().child('EventLinks');
final dbEventFeedbackResponses = FirebaseDatabase.instance.reference().child('EventFeedbackResponses');
final dbEventCollaborators = FirebaseDatabase.instance.reference().child('EventCollaborators');
final dbEventNotifications = FirebaseDatabase.instance.reference().child('EventNotifications');
final dbUserNotifications = FirebaseDatabase.instance.reference().child('UserNotifications');
final dbMyAccount = FirebaseDatabase.instance.reference().child('MyAccount');
final dbMyAccountOld = FirebaseDatabase.instance.reference().child('Users');
//final dbSessions = FirebaseDatabase.instance.reference().child('Modules');
//final dbEarnedBooths = FirebaseDatabase.instance.reference().child('EarnedBooths');
//final dbEarnedBadges = FirebaseDatabase.instance.reference().child('EarnedBadges');
//final dbEventBooths = FirebaseDatabase.instance.reference().child('EventBooths');
//final dbEventBadges = FirebaseDatabase.instance.reference().child('EventBadges');
final dbCalendar = FirebaseDatabase.instance.reference().child('Calendar');
final dbRegistrations = FirebaseDatabase.instance.reference().child('Registrations');
//final dbSessionRegistrations = FirebaseDatabase.instance.reference().child('SessionRegistrations');
//final dbAttendance = FirebaseDatabase.instance.reference().child('Attendance');
//final dbSessionAttendance = FirebaseDatabase.instance.reference().child('SessionAttendance');
//final dbKiosk = FirebaseDatabase.instance.reference().child('Kiosk');
//final dbFeedback = FirebaseDatabase.instance.reference().child("Feedback");
final dbQuestions = FirebaseDatabase.instance.reference().child("Questions");
//final dbNotifications = FirebaseDatabase.instance.reference().child('Notifications');
//final dbUserInfo = FirebaseDatabase.instance.reference().child('Users');
//final dbAdmins = FirebaseDatabase.instance.reference().child('Admins');
//final dbBadges = FirebaseDatabase.instance.reference().child('Badges');
//final dbTopics = FirebaseDatabase.instance.reference().child('Topics');

class FirebaseMethods {
  static void getCalendarByUserID(String userID, void onData(Map data)) {
    dbCalendar.child(userID).once().then((DataSnapshot ss) {
      onData(ss.value);
    });
  }

  static void setMyAccount(String uuid, Map data, void onData()) {
    dbMyAccount.child(uuid).set(data).whenComplete(onData);
  }

  static void getMyAccount(String uuid, void onData(Map data)) {
    dbMyAccount.child(uuid).once().then((DataSnapshot ss) {
      onData(ss.value);
    });
  }

  static void getMyAccountOld(String userid, void onData(Map data)) {
    dbMyAccountOld.child(userid).once().then((DataSnapshot ss) {
      onData(ss.value);
    });
  }

  static void getEventsByActiveStatus(void onData(Map data)) {
    dbEventList.once().then((DataSnapshot ss) {
      onData(ss.value);
    });
  }

  static void getEventByEventID(String eventID, void onData(Map data)) {
    dbEventList.child(eventID).once().then((DataSnapshot ss) => onData(ss.value));
  }

  static void getAttendeesByEventID(String eventID, void onData(Map data)) {
    dbRegistrations.child(eventID).once().then((DataSnapshot ss) {
      onData(ss.value);
    });
  }

  static void setAttendanceByAttendee(String eventID, String userID, Map attendance, void onData(Map data)) {
    DatabaseReference myAttendance = dbRegistrations.child(eventID).child(userID);
    myAttendance.set(attendance).whenComplete(() => myAttendance.once().then((DataSnapshot ss) => onData(ss.value)));
  }

  static void setAttendanceFeedbackSent(String eventID, String userID, void onData(Map data)) {
    DatabaseReference myAttendance = dbRegistrations.child(eventID).child(userID);
    myAttendance.child('Feedback').set(true).whenComplete(() => myAttendance.once().then((DataSnapshot ss) => onData(ss.value)));
  }

  static void setEventQuestion(String eventID, Map data, void onData()) {
    dbQuestions.child(eventID).push().set(data).whenComplete(onData);
  }

  static Future<StreamSubscription<Event>> getEventQuestionsByEventIDRefresh(String eventID, void onData(Map todo)) async {
    StreamSubscription<Event> subscription = dbQuestions.child(eventID).onValue.listen((Event e) {
      onData(e.snapshot.value);
    });
    return subscription;
  }
  static Future<StreamSubscription<Event>> getAllNotificationsByUserID(String userID, void onData(Map todo)) async {
    StreamSubscription<Event> subscription = dbUserNotifications.child(userID).onValue.listen((Event e) {
      onData(e.snapshot.value);
    });
    return subscription;
  }

  static void getEventQuestionsByEventID(String eventID, void onData(Map data)) {
    dbQuestions.child(eventID).once().then((DataSnapshot ss) => onData(ss.value));
  }

  static void setQuestionVoteByUserID(String eventID, String questionID, String userID, void onData()) {
    dbQuestions.child(eventID).child(questionID).child('Votes').child(userID).set(true).whenComplete(onData);
  }
  static void setQuestionVoteByUserID2(String eventID, String questionID, String userID, void onData(Map data)) {
    DatabaseReference setVote = dbQuestions.child(eventID).child(questionID).child('Votes');
    setVote.child(userID).set(true).whenComplete(() => setVote.once().then((DataSnapshot ss) => onData(ss.value)));
  }

  static void setAttendeeNotificationByEventID(String eventID, String message, void onData()) {
    dbEventNotifications.child(eventID).set(message).whenComplete(onData);
  }

  static void getEventQuestionsByUserID(String eventID, String userID, void onData(Map data)) {
    dbQuestions.child(eventID).orderByChild('UserID').equalTo(userID).once().then((DataSnapshot ss) => onData(ss.value));
  }

  static void getFeedbackQuestionsByEventID(String eventID, void feedbackRetrieved(Map data)) {
    dbEventFeedback.child(eventID).once().then((DataSnapshot ss) => feedbackRetrieved(ss.value));
  }

  static void setFeedbackQuestions() {}

  static void getFeedbackAnswersByEventID() {}

  static void getFeedbackAnswersByUserID(String eventID, String userID, Map data, void onData()) {}

  static void setFeedbackAnswers(String eventID, String userID, Map data, void onData()) {
    dbEventFeedbackResponses.child(eventID).child(userID).set(data).whenComplete(onData);
  }

  static void getEventCollaboratorsByEventID(String eventID, void onData(Map data)) {
    dbEventCollaborators.child(eventID).once().then((DataSnapshot ss) => onData(ss.value));
  }

  static void getEventLinksByEventID(String eventID, void onData(Map data)) {
    dbEventLinks.child(eventID).once().then((DataSnapshot ss) => onData(ss.value));
  }

  static void setEventCollaborator(String eventID, String uid, bool status, void onData(Map data), {String e}) {
    DatabaseReference collab = dbEventCollaborators.child(eventID);
    collab.child(uid).set(status ? (e != null ? e : uid) : null).whenComplete(() => collab.once().then((DataSnapshot ss) => onData(ss.value)));
  }

//
//  static Future getEvent(String eventID, void onData(ItemEvent todo)) async {
//    dbEvents.child(eventID).once().then((DataSnapshot snapshot) {
//      onData(new ItemEvent.fromJson(snapshot.key, snapshot.value));
//    });
//  }
//
//  static void registerToken(String token, String userKey) {
//    dbUserInfo.child(userKey).child("FCMToken").set(token);
//  }
//
//  static void getUserInfo(userKey, void onData(ItemProfile p), void noData()) {
//    dbUserInfo.child(userKey).once().then((DataSnapshot snapshot) {
//      if (snapshot.value != null) {
//        onData(new ItemProfile.fromJson(snapshot.value));
//      } else {
//        noData();
//      }
//    });
//  }
//
//  static void saveUserInfo(ItemProfile profile) {
//    dbUserInfo.child(profile.userKey).set({
//      'Name': {'Full': profile.name, 'First': profile.firstName, 'Last': profile.lastName},
//      'email': profile.email,
//      'Company': profile.company,
//      'Group': profile.group,
//      'ID Number': profile.idNumber,
//      'Division': profile.division,
//      'Department': profile.department,
//      'FCMToken': profile.token,
//      'Photo': profile.photo
//    }).whenComplete(() {
////      onData(sessionKey);
//    });
//  }
//
//  static Future<StreamSubscription<Event>> getEventQuestions(String filter, void onData(ListEventQuestion todo)) async {
//    StreamSubscription<Event> subscription = dbQuestions.orderByChild("QuestionKey").equalTo(filter).onValue.listen((Event event) {
//      onData(ListEventQuestion.fromJson(event.snapshot.key, event.snapshot.value));
//    });
//    return subscription;
//  }
//
//  static Future<StreamSubscription<Event>> getEventFeedback(String filter, void onData(ListEventFeedback todo)) async {
//    StreamSubscription<Event> subscription = dbFeedback.orderByChild("FeedbackKey").equalTo(filter).onValue.listen((Event event) {
//      onData(ListEventFeedback.fromJson(event.snapshot.key, event.snapshot.value));
//    });
//    return subscription;
//  }
//
//  //TODO remove subscription
//  static Future<StreamSubscription<Event>> getPrivateEvents(String filter, List<ItemEvent> eventList, void onData(ListEvent todo)) async {
//    StreamSubscription<Event> subscription = dbEvents.orderByChild(filter).equalTo(true).onValue.listen((Event event) {
//      var todos = new ListEvent.appendFromJson(eventList, event.snapshot.value);
//      onData(todos);
//    });
//
//    return subscription;
//  }
//
//  static Future getCreatedEvents(String filter, void onData(ListEvent todo)) async {
//    dbEvents.orderByChild("Creator").equalTo(filter).once().then((DataSnapshot snapshot) {
//      onData(new ListEvent.fromJson(snapshot.value));
//    });
//  }
//
//  static Future getAttendingEvents(String filter, void onData(ItemEvent todo)) async {
//    dbCalendar.child(filter).once().then((DataSnapshot s) {
//      s.value.forEach((k, v) {
//        print(k + " EVENT KEY");
//        dbEvents.child(k).once().then((DataSnapshot ss) {
//          if (ss.value != null) onData(new ItemEvent.fromJson(k, ss.value));
//        });
//      });
//    });
//  }
//
//  //TODO remove subscription
//  static Future<StreamSubscription<Event>> getMyEvents(String filter, void onData(ListEvent todo)) async {
//    StreamSubscription<Event> subscription =
//        FirebaseDatabase.instance.reference().child('Events').orderByChild(filter).equalTo(true).onValue.listen((Event event) {
//      var todos = new ListEvent.fromJson(event.snapshot.value);
//      onData(todos);
//    });
//
//    return subscription;
//  }
//
//  //TODO remove subscription
//  static Future getSessionDetails(String filter, void onData(ListSession todo), void onNull()) async {
//    dbSessions.orderByChild("EventID").equalTo(filter).once().then((DataSnapshot event) {
//      if (event.value != null) {
//        new ListSession.fromJson(event.key, event.value);
//        onData(new ListSession.fromJson(event.key, event.value));
//      } else {
//        onNull();
//      }
//    });
////    StreamSubscription<Event> subscription =
////        FirebaseDatabase.instance.reference().child('Modules').orderByChild("EventID").equalTo(filter).onValue.listen((Event event) {
////      if (event.snapshot.value != null) onData();
////    });
////
////    return subscription;
//  }
//
//  static Future getAttendees(String eventID, void onData(ListEventAttendees todo)) async {
//    dbRegistrations.child(eventID).once().then((DataSnapshot snapshot) {
//      onData(ListEventAttendees.fromJson(eventID, snapshot.value));
//    });
//  }
//
//  static Future getEventBooths(String eventID, void onData(ListBooths todo), void noData()) async {
//    dbEventBooths.orderByChild('EventID').equalTo(eventID).once().then((DataSnapshot snapshot) {
//      if (snapshot.value != null) {
//        print("MAY BOOTS");
//        onData(ListBooths.fromJson(eventID, snapshot.value));
//      } else {
//        noData();
//      }
//    });
//  }
//
//  static Future getEventBadges(String eventID, void onData(ListBadges todo), void noData()) async {
//    dbEventBadges.orderByChild('EventID').equalTo(eventID).once().then((DataSnapshot snapshot) {
//      if (snapshot.value != null) {
//        print("MAY BAJ");
//        onData(ListBadges.fromJson(eventID, snapshot.value));
//      } else {
//        noData();
//      }
//    });
//  }
//
//  static Future getSessionAttendees(String sessionID, void onData(ListSessionAttendees todo)) async {
//    dbSessionRegistrations.child(sessionID).once().then((DataSnapshot snapshot) {
//      onData(ListSessionAttendees.fromJson(sessionID, snapshot.value));
//    });
//  }
//
//  static void createToken(String eventID, void onCreate(String token)) {
////    String token = StringUtil.randomString(4);
//    String token = dbEvents.child(eventID).child('Tokens').push().key;
//    dbEvents.child(eventID).child('Tokens').child(token).set("NEW").whenComplete(() {
//      onCreate(token);
//    });
//  }
//
//  static Future<StreamSubscription<Event>> getQR(String eventID, String token, void onData(String key)) async {
//    StreamSubscription<Event> subscription = dbEvents.child(eventID).child("Tokens").child(token).onValue.listen((Event event) {
//      onData(event.snapshot.value);
//    });
//
//    return subscription;
//  }
//
//  static void registerMeEvent(String userKey, String eventID) {
//    dbRegistrations.child(eventID).child(userKey).set({'Status': false, 'Time': DateTime.now().toString()});
//  }
//
//  static void confirmAttendance(String eventID, String time) {
//    AppPreferences.getLogin((ItemProfile me) {
//      String userKey = me.userKey;
//      dbRegistrations.child(eventID).child(userKey).child("Status").set(true);
//      dbRegistrations.child(eventID).child(userKey).child("Time").set(time);
//    });
//  }
//
//  static void reverseConfirmAttendance(String userKey, String eventID, String time) {
//    dbRegistrations.child(eventID).child(userKey).child("Status").set(true);
//    dbRegistrations.child(eventID).child(userKey).child("Time").set(time);
//  }
//
//  static void reverseConfirmAttendanceSession(String userKey, String eventID, String sessionID, String slot, String time, void onData(bool success)) {
//    dbRegistrations.child(eventID).child(userKey).child(slot).once().then((DataSnapshot ds) {
//      if (ds.value != null) {
//        if (ds.value['Session'] == sessionID) {
//          dbRegistrations.child(eventID).child(userKey).child(slot).child("Confirmed").set(true).whenComplete(() {
//            onData(true);
//          });
//          dbRegistrations.child(eventID).child(userKey).child(slot).child("Time").set(time);
//          dbSessionRegistrations.child(sessionID).child(userKey).set(true);
//        } else {
//          onData(false);
//        }
//      } else {
//        onData(false);
//      }
//    });
//  }
//
//  static void reverseFinishAttendanceSession(String userKey, String eventID, String sessionID, String slot, String time, void onData(bool success)) {
//    dbRegistrations.child(eventID).child(userKey).child(slot).once().then((DataSnapshot ds) {
//      if (ds.value != null) {
//        if (ds.value['Session'] == sessionID) {
//          dbRegistrations.child(eventID).child(userKey).child(slot).child("Done").set(true).whenComplete(() {
//            onData(true);
//          });
//        } else {
//          onData(false);
//        }
//      } else {
//        onData(false);
//      }
//    });
//  }
//
//  static void confirmAttendanceQR(String userKey, String eventID, String token, String key) {
//    dbAttendance.child(eventID).push().set({'Finished': false, 'User': userKey, 'Token': token, 'Key': key, 'Time': DateTime.now().toString()});
//  }
//
//  static void finishAttendanceQR(String userKey, String eventID, String token, String key) {
//    dbAttendance.child(eventID).push().set({'Finished': true, 'User': userKey, 'Token': token, 'Key': key, 'Time': DateTime.now().toString()});
//  }
//
////  static void earnBadge(String userKey, String eventID, String badgeKey, void onData(bool success)) {
////    dbBadges.child(eventID).child(userKey).child(badgeKey).set(DateTime.now().toString()).whenComplete(() {
////      onData(true);
////    });
////  }
//
//  static void earnBadge(String badge, String eventID) {
//    AppPreferences.getLogin((ItemProfile me) {
//      String userKey = me.userKey;
//      dbEarnedBadges.child(eventID).push().set({'User': userKey, 'Badge': badge});
//    });
//  }
//
//  static void consumeBooth(String booth, String eventID) {
//    AppPreferences.getLogin((ItemProfile me) {
//      String userKey = me.userKey;
//      dbEarnedBooths.child(eventID).push().set({'User': userKey, 'Booth': booth});
//    });
//  }
//
//  static void getMyBadges(String userKey, String eventID, void onData(UserBadges success)) {
//    dbBadges.child(eventID).child(userKey).once().then((DataSnapshot snapshot) {
//      onData(new UserBadges.fromJson(snapshot.value));
//    });
//  }
//
//  static void getEarnedBooths(String userKey, String eventID, void onData(EarnedBoothList ebl)) {
//    dbEarnedBooths.child(eventID).orderByChild('User').equalTo(userKey).once().then((DataSnapshot snapshot) {
//      if (snapshot.value != null) {
//        onData(EarnedBoothList.fromJson(snapshot.value));
//      }
//    });
//  }
//
//  static void getEarnedBadges(String userKey, String eventID, void onData(EarnedBadgeList ebl)) {
//    dbEarnedBadges.child(eventID).orderByChild('User').equalTo(userKey).once().then((DataSnapshot snapshot) {
//      if (snapshot.value != null) {
//        onData(EarnedBadgeList.fromJson(snapshot.value));
//      }
//    });
//  }
//
//  //TODO functionality
//  static void confirmSessionQR(String userKey, String eventID, String sessionID, String slot, String token, String key) {
//    dbSessionAttendance
//        .child(eventID)
//        .child(slot)
//        .child(sessionID)
//        .push()
//        .set({'Finished': false, 'User': userKey, 'Token': token, 'Key': key, 'Time': DateTime.now().toString()});
//  }
//
//  static void finishSessionQR(String userKey, String eventID, String sessionID, String slot, String token, String key) {
//    dbSessionAttendance
//        .child(eventID)
//        .child(slot)
//        .child(sessionID)
//        .push()
//        .set({'Finished': true, 'User': userKey, 'Token': token, 'Key': key, 'Time': DateTime.now().toString()});
//  }
//
//  static Future registerMeSession(String userKey, String eventID, String sessionID, String slot, Future onRegister()) async {
//    dbRegistrations.child(eventID).child(userKey).child(slot).once().then((DataSnapshot snapshot) {
//      dbRegistrations.child(eventID).child(userKey).child("Sessions").set(true);
//      dbSessionRegistrations.child(sessionID).child(userKey).set(false);
//      if (snapshot.value != null && snapshot.value.containsKey('Session'))
//        dbSessionRegistrations.child(snapshot.value['Session']).child(userKey).remove();
//      dbRegistrations
//          .child(eventID)
//          .child(userKey)
//          .child(slot)
//          .set({'Done': false, 'Confirmed': false, 'Session': sessionID, 'Time': DateTime.now().toString()}).whenComplete(onRegister);
//    });
//  }
//
//  static Future cancelRegistration(String userKey, String eventID, String reason) async {
//    dbRegistrations.child(eventID).child(userKey).set({'Reason': reason});
//  }
//
//  static Future cancelRegistrationSession(String userKey, String eventID, String slot, String reason) async {
//    dbRegistrations.child(eventID).child(userKey).child(slot).once().then((DataSnapshot snapshot) {
//      if (snapshot.value != null && snapshot.value.containsKey('Session'))
//        dbSessionRegistrations.child(snapshot.value['Session']).child(userKey).remove();
//      dbRegistrations.child(eventID).child(userKey).child(slot).set({'Reason': reason});
//    });
//  }
//
//  static Future getAttendance(String eventID, String userKey, void showRegistration(ItemRegistration reg), void onNoData()) async {
//    dbRegistrations.child(eventID).child(userKey).once().then((DataSnapshot snapshot) {
//      if (snapshot.value != null) {
//        showRegistration(new ItemRegistration.fromJson(snapshot.key, snapshot.value));
////        if (snapshot.value['Sessions'] == true) {
////          hasSessions(new ListSessionRegistrations.fromJson(snapshot.key, snapshot.value));
////        } else {
////          if (snapshot.value['Status'] != null) {
////            if (snapshot.value['Status']) {
////              isConfirmed();
////            } else {
////              hasEvent();
////            }
////          } else {
////            onNoData();
////          }
////        }
//      } else {
//        onNoData();
//      }
//    });
//  }
//
//  static Future getTopics(String key, void showTopics(ListTopics tops)) async {
//    dbTopics.child(key).once().then((DataSnapshot snapshot) {
//      print(key);
//      print(snapshot.value);
//      if (snapshot.value != null) {
//        showTopics(new ListTopics.fromJson(snapshot.key, snapshot.value));
//      }
//    });
//  }
//
//  static Future getAdmins(String userKey, void onData(bool isAdmin)) async {
//    dbAdmins.child(userKey).once().then((DataSnapshot snapshot) {
//      if (snapshot.value != null) {
//        onData(true);
//      } else {
//        onData(false);
//      }
//    });
//  }
//
//  //TODO reference
//  static void submitQuestion(ItemProfile profile, String key, String s) {
//    final reference = FirebaseDatabase.instance.reference().child("Questions");
//    reference.push().set({'Question': s, 'Time': new DateTime.now().toString(), 'Name': profile.name, 'QuestionKey': key, 'Photo': profile.photo});
//  }
//
//  static void createFeedback(String sessionKey, String eventKey, ItemFeedback fb) {
//    Map<String, String> choices = {};
//    if (fb.choiceList.length > 0) {
//      fb.choiceList.forEach((Choice c) {
//        choices[choices.length.toString()] = c.choice;
//      });
//    }
//    if (sessionKey != null) {
//      dbSessions.child(sessionKey).child('Questions').push().set({'Q': fb.question, 'T': fb.type, 'Choices': choices});
//    } else {
//      dbEvents.child(eventKey).child('Questions').push().set({'Q': fb.question, 'T': fb.type, 'Choices': choices});
//    }
//  }
//
//  static void submitFeedback(ItemProfile profile, String eventKey, String sessionKey, List<ItemFeedbackResponse> s, String slot) {
//    List<Map<String, String>> feedback = <Map<String, String>>[];
//    void iterateFeedback(ItemFeedbackResponse s) {
//      Map<String, String> fb = {'Q': s.question, 'A': s.answer};
//      feedback.add(fb);
//    }
//
//    s.forEach(iterateFeedback);
//
//    if (slot == null) {
//      dbFeedback.push().set({'Name': profile.name, 'FeedbackKey': eventKey, 'Feedback': feedback, 'Time': new DateTime.now().toString()});
//      dbRegistrations.child(eventKey).child(profile.userKey).child("Feedback").set(true);
//    } else {
//      dbFeedback.push().set({'Name': profile.name, 'FeedbackKey': sessionKey, 'Feedback': feedback, 'Time': new DateTime.now().toString()});
//      dbRegistrations.child(eventKey).child(profile.userKey).child(slot).child("Feedback").set(true);
//    }
////    https://globe-isg-punch.firebaseio.com/Registrations/-LCEeln4cfVVNhCM7jSA/vcbrillantesglobecomph
//  }
//
//  static void projectQuestion(ItemEventQuestion e) {
//    dbKiosk.child(e.eventKey).child('Question').set({'Name': e.name, 'Question': e.question});
//  }
//
//  static void createBadge(String eventKey, ItemEventBadge newBadge) {
//    String badgeKey;
//    newBadge.key == "NEW" ? badgeKey = dbSessions.push().key : badgeKey = newBadge.key;
//    dbEvents
//        .child(eventKey)
//        .child('Badges')
//        .child(badgeKey)
//        .set({'Name': newBadge.name, 'EventID': newBadge.eventID, 'Icon': newBadge.icon}).whenComplete(() {
////      onData(badgeKey);
//    });
//  }
//
//  static void submitCollaborator(String key, String email) {
//    print(key + " " + email + " " + AccountUtils.getUserKey(email));
//    dbEvents.child(key).child('Collaborators').child(AccountUtils.getUserKey(email)).set(email);
//  }
//
//  static void submitSession(String eventKey, ItemSession newSession, void onData(String sessionID)) {
//    String sessionKey;
//    newSession.key == "NEW" ? sessionKey = dbSessions.push().key : sessionKey = newSession.key;
//    dbSessions.child(sessionKey).set({
//      'TimeStart': newSession.session.start.dbtime,
//      'TimeEnd': newSession.session.end.dbtime,
//      'EventID': eventKey,
//      'Description': newSession.session.description,
//      'Slot': newSession.slot,
//      'Name': newSession.session.name,
//      'EventDay': newSession.session.start.longdate,
//      'EndTime': newSession.session.end.time,
//      'StartTime': newSession.session.start.time,
//      'Venue': newSession.session.venue
//    }).whenComplete(() {
//      onData(sessionKey);
//    });
//  }
//
//  static void submitEvent(String creator, ItemEvent newEvent, void onData(String sessionID)) {
//    String eventKey;
//    newEvent.key == "new" ? eventKey = dbEvents.push().key : eventKey = newEvent.key;
//    dbEvents.child(eventKey).set({
//      'Booths': newEvent.booths,
//      'Active': true,
//      'Name': newEvent.event.name,
//      'Description': newEvent.event.description,
//      'Brief': newEvent.brief,
//      'Questions': newEvent.feedbackQuestions,
//      'Venue': newEvent.event.venue,
//      'GCalID': newEvent.gCalID,
//      'VenueSpec': newEvent.venueSpec,
//      'CanAsk': newEvent.canAsk,
//      'StartDate': newEvent.event.start.dbtime,
//      'Badges': newEvent.badges,
//      'Collaborators': newEvent.collaborators,
//      'EndDate': newEvent.event.end.dbtime,
//      'Banner': newEvent.banner,
//      'Creator': creator,
//      'Globe': newEvent.globe,
//      'Public': newEvent.public,
//      'ScanParam': newEvent.scanParam
//    }).whenComplete(() {
//      onData(eventKey);
//    });
//  }
}
